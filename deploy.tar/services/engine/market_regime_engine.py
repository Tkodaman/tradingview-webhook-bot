"""
Piyasa Rejimi Motoru (Market Regime Engine)
===========================================
Her döngüde canlı piyasa verilerini okuyarak CRYPTO, NASDAQ ve BIST için
ayrı ayrı rejim hesaplar (MEGA_BULL / BULL / SIDEWAYS / BEAR / CRASH).

Risk Modu x Piyasa Rejimi -> 2D Karar Matrisi:
 - Giris Esigi (min_score, min_vol)
 - TP/SL Genisligi
 - Trailing Stop Makasi
 - Sermaye Carpani
 - Maksimum Acik Pozisyon
"""

from core.logger import logger
from services.engine.risk_engine import RiskEngine

# ─────────────────────────────────────────────
# REJIM SABITLERI
# ─────────────────────────────────────────────
REGIME_MEGA_BULL = "MEGA_BULL"
REGIME_BULL      = "BULL"
REGIME_SIDEWAYS  = "SIDEWAYS"
REGIME_BEAR      = "BEAR"
REGIME_CRASH     = "CRASH"

ALL_REGIMES = [REGIME_CRASH, REGIME_BEAR, REGIME_SIDEWAYS, REGIME_BULL, REGIME_MEGA_BULL]

# ─────────────────────────────────────────────
# 2D KARAR MATRISI
# ─────────────────────────────────────────────
DECISION_MATRIX = {
    "SNIPER": {
        REGIME_MEGA_BULL: dict(min_score=2, min_vol=0.4, tp_pct=3.5,  sl_pct=1.8,  capital_mult=1.5, max_global_pos=15, max_market_pos=6,  entry_allowed=True),
        REGIME_BULL:      dict(min_score=3, min_vol=0.5, tp_pct=3.0,  sl_pct=1.6,  capital_mult=1.2, max_global_pos=12, max_market_pos=5,  entry_allowed=True),
        REGIME_SIDEWAYS:  dict(min_score=4, min_vol=0.7, tp_pct=2.5,  sl_pct=1.5,  capital_mult=1.0, max_global_pos=8,  max_market_pos=3,  entry_allowed=True),
        REGIME_BEAR:      dict(min_score=7, min_vol=1.2, tp_pct=2.0,  sl_pct=1.4,  capital_mult=0.5, max_global_pos=3,  max_market_pos=1,  entry_allowed=False),
        REGIME_CRASH:     dict(min_score=9, min_vol=2.0, tp_pct=1.8,  sl_pct=1.2,  capital_mult=0.0, max_global_pos=0,  max_market_pos=0,  entry_allowed=False),
    },
    "AGGRESSIVE": {
        REGIME_MEGA_BULL: dict(min_score=2, min_vol=0.5, tp_pct=3.8,  sl_pct=2.0,  capital_mult=1.5, max_global_pos=20, max_market_pos=8,  entry_allowed=True),
        REGIME_BULL:      dict(min_score=2, min_vol=0.6, tp_pct=3.2,  sl_pct=1.8,  capital_mult=1.3, max_global_pos=15, max_market_pos=6,  entry_allowed=True),
        REGIME_SIDEWAYS:  dict(min_score=3, min_vol=0.8, tp_pct=2.8,  sl_pct=1.6,  capital_mult=1.0, max_global_pos=10, max_market_pos=4,  entry_allowed=True),
        REGIME_BEAR:      dict(min_score=4, min_vol=1.0, tp_pct=2.2,  sl_pct=1.5,  capital_mult=0.8, max_global_pos=5,  max_market_pos=2,  entry_allowed=True),
        REGIME_CRASH:     dict(min_score=6, min_vol=2.0, tp_pct=1.8,  sl_pct=1.2,  capital_mult=0.5, max_global_pos=2,  max_market_pos=1,  entry_allowed=True),
    },
    "NORMAL": {
        REGIME_MEGA_BULL: dict(min_score=4, min_vol=0.7, tp_pct=8.0,  sl_pct=3.5,  capital_mult=1.1, max_global_pos=10, max_market_pos=4,  entry_allowed=True),
        REGIME_BULL:      dict(min_score=5, min_vol=0.8, tp_pct=6.0,  sl_pct=3.0,  capital_mult=1.0, max_global_pos=10, max_market_pos=4,  entry_allowed=True),
        REGIME_SIDEWAYS:  dict(min_score=6, min_vol=1.0, tp_pct=5.0,  sl_pct=2.5,  capital_mult=0.8, max_global_pos=6,  max_market_pos=2,  entry_allowed=True),
        REGIME_BEAR:      dict(min_score=7, min_vol=1.2, tp_pct=3.5,  sl_pct=2.0,  capital_mult=0.5, max_global_pos=3,  max_market_pos=1,  entry_allowed=True),
        REGIME_CRASH:     dict(min_score=9, min_vol=2.0, tp_pct=2.0,  sl_pct=1.5,  capital_mult=0.0, max_global_pos=0,  max_market_pos=0,  entry_allowed=False),
    },
    "TIGHT": {
        REGIME_MEGA_BULL: dict(min_score=5, min_vol=0.9, tp_pct=4.0,  sl_pct=2.5,  capital_mult=0.9, max_global_pos=6,  max_market_pos=2,  entry_allowed=True),
        REGIME_BULL:      dict(min_score=6, min_vol=1.0, tp_pct=3.5,  sl_pct=2.0,  capital_mult=0.8, max_global_pos=5,  max_market_pos=2,  entry_allowed=True),
        REGIME_SIDEWAYS:  dict(min_score=7, min_vol=1.2, tp_pct=3.0,  sl_pct=1.8,  capital_mult=0.7, max_global_pos=4,  max_market_pos=1,  entry_allowed=True),
        REGIME_BEAR:      dict(min_score=8, min_vol=1.5, tp_pct=2.0,  sl_pct=1.5,  capital_mult=0.4, max_global_pos=2,  max_market_pos=1,  entry_allowed=True),
        REGIME_CRASH:     dict(min_score=9, min_vol=2.0, tp_pct=1.5,  sl_pct=1.2,  capital_mult=0.0, max_global_pos=0,  max_market_pos=0,  entry_allowed=False),
    },
    "CONSERVATIVE": {
        REGIME_MEGA_BULL: dict(min_score=6, min_vol=1.0, tp_pct=3.0,  sl_pct=1.5,  capital_mult=0.8, max_global_pos=4,  max_market_pos=2,  entry_allowed=True),
        REGIME_BULL:      dict(min_score=7, min_vol=1.2, tp_pct=2.5,  sl_pct=1.2,  capital_mult=0.7, max_global_pos=3,  max_market_pos=1,  entry_allowed=True),
        REGIME_SIDEWAYS:  dict(min_score=9, min_vol=1.5, tp_pct=2.0,  sl_pct=1.0,  capital_mult=0.0, max_global_pos=0,  max_market_pos=0,  entry_allowed=False),
        REGIME_BEAR:      dict(min_score=9, min_vol=2.0, tp_pct=1.2,  sl_pct=0.8,  capital_mult=0.0, max_global_pos=0,  max_market_pos=0,  entry_allowed=False),
        REGIME_CRASH:     dict(min_score=9, min_vol=2.0, tp_pct=1.0,  sl_pct=0.6,  capital_mult=0.0, max_global_pos=0,  max_market_pos=0,  entry_allowed=False),
    },
}

# Kripto TP/SL carpanlari (Volatilite toleransi)
CRYPTO_TP_MULTIPLIER = 1.25
CRYPTO_SL_MULTIPLIER = 1.30

# ─────────────────────────────────────────────
# TRAILING STOP MATRISI
# [(kar_esigi, dist), ...]  dist=None -> trailing henuz aktif degil
# ─────────────────────────────────────────────
TRAILING_MATRIX = {
    "SNIPER": {
        REGIME_MEGA_BULL: [(3.0, 0.008), (2.0, 0.012), (1.2, 0.015), (0.0, None)],
        REGIME_BULL:      [(2.8, 0.008), (1.8, 0.012), (1.0, 0.015), (0.0, None)],
        REGIME_SIDEWAYS:  [(2.2, 0.008), (1.4, 0.010), (0.8, 0.014), (0.0, None)],
        REGIME_BEAR:      [(1.8, 0.006), (1.0, 0.008), (0.6, 0.012), (0.0, None)],
        REGIME_CRASH:     [(1.0, 0.005), (0.5, 0.008), (0.0, None)],
    },
    "AGGRESSIVE": {
        REGIME_MEGA_BULL: [(3.5, 0.010), (2.4, 0.015), (1.5, 0.018), (0.0, None)],
        REGIME_BULL:      [(3.0, 0.010), (2.0, 0.014), (1.2, 0.018), (0.0, None)],
        REGIME_SIDEWAYS:  [(2.5, 0.010), (1.6, 0.012), (0.9, 0.016), (0.0, None)],
        REGIME_BEAR:      [(2.0, 0.008), (1.2, 0.010), (0.7, 0.014), (0.0, None)],
        REGIME_CRASH:     [(1.2, 0.006), (0.6, 0.008), (0.0, None)],
    },
    "NORMAL": {
        REGIME_MEGA_BULL: [(8.0, 0.025), (4.0, 0.035), (2.0, 0.045), (0.0, None)],
        REGIME_BULL:      [(6.0, 0.025), (3.0, 0.035), (1.5, 0.045), (0.0, None)],
        REGIME_SIDEWAYS:  [(4.0, 0.020), (2.0, 0.030), (1.0, 0.035), (0.0, None)],
        REGIME_BEAR:      [(2.5, 0.015), (1.5, 0.020), (0.0, None)],
        REGIME_CRASH:     [(1.5, 0.010), (0.0, None)],
    },
    "TIGHT": {
        REGIME_MEGA_BULL: [(4.0,  0.010), (2.0, 0.015), (1.0, 0.020), (0.0, None)],
        REGIME_BULL:      [(3.0,  0.008), (1.5, 0.012), (0.8, 0.018), (0.0, None)],
        REGIME_SIDEWAYS:  [(2.0,  0.006), (1.0, 0.010), (0.0, None)],
        REGIME_BEAR:      [(1.2,  0.005), (0.6, 0.008), (0.0, None)],
        REGIME_CRASH:     [(0.5,  0.003), (0.0, None)],
    },
    "CONSERVATIVE": {
        REGIME_MEGA_BULL: [(3.0,  0.008), (1.8, 0.012), (1.0, 0.016), (0.0, None)],
        REGIME_BULL:      [(2.5,  0.008), (1.5, 0.010), (0.7, 0.015), (0.0, None)],
        REGIME_SIDEWAYS:  [(1.8,  0.006), (0.8, 0.008), (0.0, None)],
        REGIME_BEAR:      [(1.0,  0.005), (0.0, None)],
        REGIME_CRASH:     [(0.5,  0.003), (0.0, None)],
    },
}


class MarketRegimeEngine:
    """
    Canli piyasa verilerini analiz edip her piyasa grubu icin rejim hesaplar.
    Risk Modu x Rejim kombinasyonundan ticaret profili ve trailing stop makasini dondurur.
    """

    def __init__(self):
        self.current_regimes: dict = {
            "CRYPTO": REGIME_SIDEWAYS,
            "NASDAQ": REGIME_SIDEWAYS,
            "BIST":   REGIME_SIDEWAYS,
        }
        self._last_update: float = 0.0

    # ─────────────────────────────────────────────
    # REJIM HESAPLAMA
    # ─────────────────────────────────────────────
    def compute_regime(self, market_prices: dict) -> dict:
        """
        Tum canli fiyat verisini alip her piyasa grubu icin rejim dondurur.
        Returns: {"CRYPTO": "MEGA_BULL", "NASDAQ": "SIDEWAYS", "BIST": "BEAR"}
        """
        import time
        self._last_update = time.time()

        groups = {"CRYPTO": [], "NASDAQ": [], "BIST": []}

        for sym, data in market_prices.items():
            if not isinstance(data, dict):
                continue
            market = data.get("market", "NASDAQ").upper()
            if market in groups:
                groups[market].append(data)

        result = {}
        for market_key, items in groups.items():
            if not items:
                result[market_key] = REGIME_SIDEWAYS
                continue
            result[market_key] = self._classify(items, market_key)

        self.current_regimes = result

        for mkt, reg in result.items():
            logger.info(f"[REGIME ENGINE] {mkt} -> {reg}")

        return result

    def _classify(self, items: list, market: str) -> str:
        """Verilen piyasa grubunun ortalamasina bakarak rejim dondurur."""
        if not items:
            return REGIME_SIDEWAYS

        avg_rsi = sum(d.get("rsi", 50.0) for d in items) / len(items)
        avg_vol = sum(d.get("volume_ratio", 1.0) for d in items) / len(items)
        avg_cmf = sum(d.get("cmf", 0.0) for d in items) / len(items)
        avg_chg = sum(d.get("change_pct", 0.0) for d in items) / len(items)

        # Eger RSI vb. disaridan gelmemisse (50.0 varsayilan ise), sadece change_pct uzerinden dinamik rejim hesapla
        if avg_rsi == 50.0 and avg_cmf == 0.0:
            if avg_chg > 2.0: return REGIME_MEGA_BULL
            if avg_chg > 0.3: return REGIME_BULL
            if avg_chg < -2.0: return REGIME_CRASH
            if avg_chg < -0.3: return REGIME_BEAR
            return REGIME_SIDEWAYS

        # Normal Otonom Kurallar
        if avg_rsi < 33 and avg_vol > 1.5 and avg_cmf < -0.10:
            return REGIME_CRASH
        if avg_rsi > 60 and avg_vol > 1.15 and avg_cmf > 0.05 and avg_chg > 0.8:
            return REGIME_MEGA_BULL
        if avg_rsi > 52 and avg_cmf >= 0 and avg_chg > 0:
            return REGIME_BULL
        if avg_rsi < 48 and avg_cmf < -0.05 and avg_chg < 0:
            return REGIME_BEAR
        if avg_rsi < 38 and avg_cmf < -0.08:
            return REGIME_BEAR

        return REGIME_SIDEWAYS

    # ─────────────────────────────────────────────
    # TICARET PROFILI
    # ─────────────────────────────────────────────
    def get_trade_profile(self, risk_mode: str, market: str) -> dict:
        """
        Risk Modu + Canli Rejim kombinasyonuna gore TP/SL/esik/sermaye profili dondurur.
        market: "CRYPTO", "NASDAQ" veya "BIST"
        """
        risk_mode = risk_mode.upper() if risk_mode else "NORMAL"
        regime = self.current_regimes.get(market.upper(), REGIME_SIDEWAYS)

        mode_matrix = DECISION_MATRIX.get(risk_mode, DECISION_MATRIX["NORMAL"])
        profile = mode_matrix.get(regime, mode_matrix[REGIME_SIDEWAYS]).copy()

        # Kripto icin TP/SL ayri ayri genislet (TP=1.25x, SL=1.33x)
        # Sonuc: Sniper+Mega Boga -> TP%10, SL%4
        if market.upper() == "CRYPTO":
            profile["tp_pct"] = round(profile["tp_pct"] * CRYPTO_TP_MULTIPLIER, 1)
            profile["sl_pct"] = round(profile["sl_pct"] * CRYPTO_SL_MULTIPLIER, 1)

        profile["regime"] = regime
        profile["market"] = market
        profile["risk_mode"] = risk_mode

        logger.debug(
            f"[REGIME PROFILE] {market}/{risk_mode}/{regime} -> "
            f"TP={profile['tp_pct']}% SL={profile['sl_pct']}% "
            f"MinScore={profile['min_score']} Entry={profile['entry_allowed']}"
        )
        return profile

    # ─────────────────────────────────────────────
    # DINAMIK RISK VE KELLY CRITERION ENTEGRASYONU
    # ─────────────────────────────────────────────
    def get_dynamic_risk_profile(self, risk_mode: str, market: str, current_price: float, atr: float, win_rate: float, win_loss_ratio: float) -> dict:
        """
        SOTA yapay zeka yükseltmesi. Mevcut statik profilin üzerine,
        ATR tabanlı Trailing Stop mesafesi ve Kelly Criterion bazlı
        dinamik pozisyon büyüklüğünü (Sizing) hesaplar.
        """
        profile = self.get_trade_profile(risk_mode, market)
        
        # Calculate dynamic position sizing via RiskEngine (Phase 3 SOTA upgrade)
        kelly_sizing = RiskEngine.calculate_kelly_fraction(win_rate, win_loss_ratio, fraction_multiplier=0.5)
        
        # Calculate ATR-based trailing distance
        # Standard deviation multiplier is usually 2.0 or 3.0. We use 2.0 for tighter SOTA stops.
        atr_stop_price = RiskEngine.calculate_atr_trailing_stop(current_price, atr, direction="LONG", multiplier=2.0)
        
        profile["dynamic_sizing_pct"] = round(kelly_sizing * 100, 2)
        profile["atr_trailing_stop_price"] = round(atr_stop_price, 2)
        
        logger.info(f"[SOTA RISK] {market} -> Kelly Sizing: %{profile['dynamic_sizing_pct']}, ATR Stop Price: {profile['atr_trailing_stop_price']}")
        return profile

    # ─────────────────────────────────────────────
    # TRAILING STOP PROFILI
    # ─────────────────────────────────────────────
    def get_trailing_dist(self, risk_mode: str, market: str, pct_gain: float):
        """
        Kar yuzdesi ve rejim/mod kombinasyonuna gore trailing mesafe (dist) dondurur.
        dist: 0.02 = zirveden %2 asagi = siki takip
              0.10 = zirveden %10 asagi = genis nefes alani

        Returns:
            float | None — None = trailing henuz aktif olmamali
        """
        risk_mode = risk_mode.upper() if risk_mode else "NORMAL"
        regime = self.current_regimes.get(market.upper(), REGIME_SIDEWAYS)

        mode_trailing = TRAILING_MATRIX.get(risk_mode, TRAILING_MATRIX["NORMAL"])
        steps = mode_trailing.get(regime, [(0.0, None)])

        # Kripto icin dist 2x genislet
        crypto_mult = 2.0 if market.upper() == "CRYPTO" else 1.0

        for threshold, dist in steps:
            if pct_gain >= threshold:
                if dist is None:
                    return None  # Trailing henuz aktif degil
                return min(dist * crypto_mult, 0.20)  # Max %20 makas

        return None

    # ─────────────────────────────────────────────
    # DASHBOARD ICIN REJIM BILGISI
    # ─────────────────────────────────────────────
    def get_regime_display(self) -> dict:
        """Dashboard icin emoji + etiket + renk bilgisi dondurur."""
        labels = {
            REGIME_MEGA_BULL: {"label": "MEGA BOGA",    "emoji": "🐂", "color": "#22c55e", "bg": "rgba(34,197,94,0.15)"},
            REGIME_BULL:      {"label": "BOGA / YUKARI", "emoji": "🚀", "color": "#4ade80", "bg": "rgba(74,222,128,0.12)"},
            REGIME_SIDEWAYS:  {"label": "YATAY / TESTERE","emoji": "✂️", "color": "#facc15", "bg": "rgba(234,179,8,0.12)"},
            REGIME_BEAR:      {"label": "AYI / DUZELTME", "emoji": "🐻", "color": "#fb7185", "bg": "rgba(244,63,94,0.12)"},
            REGIME_CRASH:     {"label": "COKUS / PANIK",  "emoji": "💥", "color": "#ef4444", "bg": "rgba(239,68,68,0.20)"},
        }
        result = {}
        for market, regime in self.current_regimes.items():
            result[market] = {
                "regime": regime,
                **labels.get(regime, {"label": regime, "emoji": "❓", "color": "#94a3b8", "bg": "rgba(148,163,184,0.1)"}),
            }
        return result


# Global singleton
regime_engine = MarketRegimeEngine()
