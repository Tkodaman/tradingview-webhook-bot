import os
from typing import Dict, Any
from core.logger import logger
from services.broker.base import BaseBroker

# Optional import, user needs to pip install alpaca-trade-api when they go live
try:
    import alpaca_trade_api as tradeapi
except ImportError:
    tradeapi = None

class AlpacaBroker(BaseBroker):
    """
    Implementation of the Alpaca Broker bridge.
    Uses environment variables ALPACA_API_KEY and ALPACA_SECRET_KEY.
    """
    
    def __init__(self, paper: bool = True):
        api_key = os.getenv("ALPACA_API_KEY", "") or os.getenv("APCA_API_KEY_ID", "")
        secret_key = os.getenv("ALPACA_SECRET_KEY", "") or os.getenv("APCA_API_SECRET_KEY", "")
        
        # alpaca_trade_api library reads these specific env var names
        if api_key:
            os.environ["APCA_API_KEY_ID"] = api_key
        if secret_key:
            os.environ["APCA_API_SECRET_KEY"] = secret_key

        self.is_paper = paper
        base_url = 'https://paper-api.alpaca.markets' if paper else 'https://api.alpaca.markets'
        
        if not tradeapi:
            logger.error("alpaca_trade_api not installed. Run 'pip install alpaca-trade-api'.")
        
        try:
            if tradeapi and api_key and secret_key:
                self.api = tradeapi.REST(api_key, secret_key, base_url, api_version='v2')
                logger.info(f"[ALPACA BRIDGE] Connected {'PAPER' if paper else 'LIVE'}")
            else:
                self.api = None
                logger.warning("[ALPACA BRIDGE] No API key — running in simulation-only mode.")
        except Exception as e:
            logger.error(f"Failed to initialize Alpaca API: {e}")
            self.api = None

    def get_account_balance(self) -> float:
        if not self.api:
            return 0.0
        try:
            account = self.api.get_account()
            return float(account.equity)
        except Exception as e:
            logger.error(f"Alpaca: Error fetching balance: {e}")
            return 0.0

    def get_cash_balance(self) -> float:
        if not self.api:
            return 0.0
        try:
            account = self.api.get_account()
            return float(account.cash)
        except Exception as e:
            logger.error(f"Alpaca: Error fetching cash: {e}")
            return 0.0

    def _format_symbol(self, symbol: str) -> str:
        sym = symbol.upper()
        if sym.endswith("USDT"):
            return sym.replace("USDT", "USD")
        # Keep slash removal for any other edge cases
        if "/" in sym:
            return sym.replace("/", "")
        return sym

    def place_market_order(self, symbol: str, side: str, qty: float, limit_price: float = None) -> Dict[str, Any]:
        if not self.api:
            return {"status": "error", "message": "API not initialized"}
        
        try:
            alpaca_sym = self._format_symbol(symbol)
            is_crypto = "USD" in alpaca_sym or "/" in alpaca_sym
            tif = "gtc" if is_crypto else "day"
            
            from core.config import settings
            ext_hours = getattr(settings, "alpaca_extended_hours", True)
            
            # GAP FIX (+2 Adım): Pre-market'te Market order atılamaz.
            if limit_price is None and not is_crypto and ext_hours:
                rt_prices = self.get_realtime_prices([alpaca_sym])
                if alpaca_sym in rt_prices and rt_prices[alpaca_sym].get("price", 0) > 0:
                    current_p = rt_prices[alpaca_sym]["price"]
                    limit_price = current_p * 1.005 if side.lower() == "buy" else current_p * 0.995
                    limit_price = round(limit_price, 2)
                    logger.info(f"🚀 [ALPACA EXT-HOURS GAP FIX] Market emri (Düz) Limit emre çevrildi: {alpaca_sym} @ {limit_price}")

            kwargs = {
                "symbol": alpaca_sym,
                "qty": qty,
                "side": side.lower(),
                "type": 'market' if limit_price is None else 'limit',
                "time_in_force": tif
            }
            if limit_price is not None:
                kwargs["limit_price"] = limit_price
                from core.config import settings
                if getattr(settings, "alpaca_extended_hours", True) and not is_crypto:
                    kwargs["extended_hours"] = True
                    kwargs["time_in_force"] = "day"
                
            order = self.api.submit_order(**kwargs)
            logger.info(f"Alpaca {'Limit' if limit_price else 'Market'} Order Placed: {side} {qty} {alpaca_sym} - OrderID: {order.id}")
            return {"status": "success", "order_id": order.id, "details": order._raw}
        except Exception as e:
            logger.error(f"Alpaca Market Order Failed for {symbol}: {e}")
            return {"status": "error", "message": str(e)}

    def place_bracket_order(self, symbol: str, side: str, qty: float, 
                            take_profit_price: float, stop_loss_price: float, limit_price: float = None) -> Dict[str, Any]:
        if not self.api:
            return {"status": "error", "message": "API not initialized"}
            
        try:
            alpaca_sym = self._format_symbol(symbol)
            is_crypto = "USD" in alpaca_sym or "/" in alpaca_sym
            tif = "gtc" if is_crypto else "day"
            
            is_fractional = (qty != int(qty)) or (qty < 1.0)
            
            from core.config import settings
            ext_hours_setting = getattr(settings, "alpaca_extended_hours", True)
            
            # Piyasalarin su an GERCEKTEN acik olup olmadigini kontrol et
            from services.risk_engine.market_hours import MarketHoursValidator
            is_currently_open, _, _ = MarketHoursValidator.is_market_open(alpaca_sym)
            
            # Eger ayar acikca VE piyasa su an KAPALIYSA (yani gercekten mesai disindaysak)
            is_actually_ext_hours = ext_hours_setting and not is_currently_open
            
            # GAP FIX (+1 Adım): Piyasa öncesi/sonrası Market Emirler (Market Order) Alpaca tarafından REDDEDİLİR.
            # Eğer limit fiyat verilmemişse ve kripto değilse, güncel canlı fiyatı çekip emir tipini Limit'e çeviriyoruz.
            if limit_price is None and not is_crypto and is_actually_ext_hours:
                rt_prices = self.get_realtime_prices([alpaca_sym])
                if alpaca_sym in rt_prices and rt_prices[alpaca_sym].get("price", 0) > 0:
                    current_p = rt_prices[alpaca_sym]["price"]
                    # Slippage Payı (Alırken %0.5 daha pahalıya kadar kabul et, satarken %0.5 daha ucuza kadar)
                    limit_price = current_p * 1.005 if side.lower() == "buy" else current_p * 0.995
                    limit_price = round(limit_price, 2)
                    logger.info(f"🚀 [ALPACA EXT-HOURS GAP FIX] Market emri otomatik olarak Limit emre çevrildi: {alpaca_sym} @ {limit_price}")

            # Piyasa öncesi/sonrası kesirli lot kullanılamaz!
            if is_fractional and not is_crypto and is_actually_ext_hours:
                logger.warning(f"Alpaca: Fractional shares are not allowed in extended hours. Rounding {qty} to {int(qty)} for {alpaca_sym}")
                qty = float(int(qty))
                is_fractional = (qty < 1.0)
                
                if is_fractional:
                    logger.error(f"Alpaca: Quantity for {alpaca_sym} is less than 1 after rounding for extended hours. Order cancelled.")
                    return {"status": "error", "message": "Quantity too small for extended hours trading (requires integer >= 1)."}

            if is_fractional:
                # === KESİRLİ LOT: Sadece standart saatlerde çalışır, Market Order zorunludur ===
                # Alpaca bracket order kesirli lot desteklemez.
                # Çözüm: Limit order + ayrı stop order + ayrı limit order
                logger.info(f"Alpaca: Fractional qty ({qty}) - limit + separate SL/TP orders for {alpaca_sym}")
                
                # Emir tipi zafiyeti (Slippage) için Smart Limit kullanımı
                order_type = 'limit' if limit_price else 'market'
                order_kwargs = {
                    "symbol": alpaca_sym,
                    "qty": qty,
                    "side": side.lower(),
                    "type": order_type,
                    "time_in_force": tif
                }
                if limit_price:
                    order_kwargs["limit_price"] = round(limit_price, 2)
                    
                order = self.api.submit_order(**order_kwargs)
                logger.info(f"Alpaca {order_type.capitalize()} Order (Fractional): {side} {qty} {alpaca_sym} - OrderID: {order.id}")

                # === AYRI STOP-LOSS EMRİ (Alpaca sunucusunda aktif kalır) ===
                sl_side = "sell" if side.lower() == "buy" else "buy"
                try:
                    sl_order = self.api.submit_order(
                        symbol=alpaca_sym,
                        qty=qty,
                        side=sl_side,
                        type='stop',
                        time_in_force=tif,
                        stop_price=round(stop_loss_price, 4)
                    )
                    logger.info(f"[SL ORDER] {alpaca_sym} SL emri Alpaca'ya gönderildi: ${stop_loss_price:.4f} - OrderID: {sl_order.id}")
                except Exception as sl_err:
                    logger.warning(f"[SL ORDER WARN] {alpaca_sym} SL emri gönderilemedi: {sl_err}. Yerel takip aktif.")

                # === AYRI TAKE-PROFIT EMRİ ===
                try:
                    tp_order = self.api.submit_order(
                        symbol=alpaca_sym,
                        qty=qty,
                        side=sl_side,
                        type='limit',
                        time_in_force=tif,
                        limit_price=round(take_profit_price, 4)
                    )
                    logger.info(f"[TP ORDER] {alpaca_sym} TP emri Alpaca'ya gönderildi: ${take_profit_price:.4f} - OrderID: {tp_order.id}")
                except Exception as tp_err:
                    logger.warning(f"[TP ORDER WARN] {alpaca_sym} TP emri gönderilemedi: {tp_err}. Yerel takip aktif.")

            else:
                from core.config import settings
                ext_hours = getattr(settings, "alpaca_extended_hours", True)
                
                kwargs = {
                    "symbol": alpaca_sym,
                    "qty": qty,
                    "side": side.lower(),
                    "type": 'limit' if (limit_price is not None and ext_hours and not is_crypto) else 'market',
                    "time_in_force": tif,
                    "order_class": 'bracket',
                    "take_profit": dict(
                        limit_price=take_profit_price,
                    ),
                    "stop_loss": dict(
                        stop_price=stop_loss_price
                    )
                }
                
                if limit_price is not None and ext_hours and not is_crypto:
                    kwargs["limit_price"] = limit_price
                    kwargs["extended_hours"] = True

                order = self.api.submit_order(**kwargs)
                logger.info(f"Alpaca Bracket Order Placed: {side} {qty} {alpaca_sym} - OrderID: {order.id} | ExtHours: {ext_hours}")
            return {"status": "success", "order_id": order.id, "details": order._raw}
        except Exception as e:
            err_str = str(e).lower()
            if "wash trade" in err_str or "complex orders" in err_str or "extended hours" in err_str:
                logger.warning(f"Alpaca rejected bracket order for {symbol} ({err_str}). Falling back to simple entry order.")
                try:
                    # Genişletilmiş saatlerde market yerine limit emri gönderilmesi şarttır
                    fallback_type = 'limit' if (limit_price is not None and ext_hours and not is_crypto) else 'market'
                    
                    fallback_kwargs = {
                        "symbol": self._format_symbol(symbol),
                        "qty": qty,
                        "side": side.lower(),
                        "type": fallback_type,
                        "time_in_force": 'day' if not is_crypto else 'gtc'
                    }
                    
                    if fallback_type == 'limit':
                        fallback_kwargs["limit_price"] = limit_price
                        fallback_kwargs["extended_hours"] = True

                    order = self.api.submit_order(**fallback_kwargs)
                    logger.info(f"Alpaca Simple Order Fallback Placed: {side} {qty} {symbol} ({fallback_type}) - OrderID: {order.id}")
                    return {"status": "success", "order_id": order.id, "details": order._raw}
                except Exception as fb_err:
                    logger.error(f"Alpaca Fallback Order also failed: {fb_err}")
                    return {"status": "error", "message": f"{str(e)} -> Fallback error: {str(fb_err)}"}
            else:
                logger.error(f"Alpaca Bracket Order Failed for {symbol}: {e}")
                return {"status": "error", "message": str(e)}


    def update_bracket_orders(self, symbol: str, take_profit_price: float = None, stop_loss_price: float = None) -> Dict[str, Any]:
        if not self.api:
            return {"status": "error"}
            
        try:
            sym = self._format_symbol(symbol)
            open_orders = self.api.list_orders(status="open", symbols=[sym])
            
            for order in open_orders:
                try:
                    if order.type == "limit" and take_profit_price:
                        # Bu Take Profit emri
                        self.api.replace_order(order.id, limit_price=take_profit_price)
                        logger.info(f"[ALPACA] {sym} TP güncellendi -> {take_profit_price}")
                    elif (order.type == "stop" or order.type == "stop_limit") and stop_loss_price:
                        # Bu Stop Loss emri
                        self.api.replace_order(order.id, stop_price=stop_loss_price)
                        logger.info(f"[ALPACA] {sym} SL güncellendi -> {stop_loss_price}")
                except Exception as ex:
                    logger.warning(f"Alpaca Emir Güncelleme Hatası ({sym}): {ex}")
                    
            return {"status": "success"}
        except Exception as e:
            logger.error(f"Alpaca Bracket Update Failed for {symbol}: {e}")
            return {"status": "error", "message": str(e)}

    def close_position(self, symbol: str) -> Dict[str, Any]:
        if not self.api:
            return {"status": "error"}
            
        try:
            # symbol'u Alpaca'nın anlayacağı slash'siz formata çevir
            sym = self._format_symbol(symbol)
            
            # 1) Olası açık emirleri (TP/SL braketleri) iptal et ki bakiye blokesi kalksın
            try:
                open_orders = self.api.list_orders(status="open", symbols=[sym])
                for order in open_orders:
                    self.api.cancel_order(order.id)
            except Exception as e:
                logger.warning(f"Açık emir iptali sırasında hata: {e}")
                
            # 2) Pozisyonu güvenle kapat
            res = self.api.close_position(sym)
            logger.info(f"Alpaca Position Closed: {sym}")
            return {"status": "success", "closed_position": res}
        except Exception as e:
            logger.error(f"Alpaca Close Position Failed for {symbol}: {e}")
            return {"status": "error", "message": str(e)}

    def get_open_positions(self) -> list:
        if not self.api:
            return []
        try:
            positions = self.api.list_positions()
            return [p._raw for p in positions]
        except Exception as e:
            logger.error(f"Alpaca Fetch Positions Failed: {e}")
            return None

    def get_pending_orders(self) -> list:
        if not self.api:
            return []
        try:
            open_orders = self.api.list_orders(status="open")
            return [o.symbol for o in open_orders]
        except Exception as e:
            logger.error(f"Alpaca Fetch Pending Orders Failed: {e}")
            return []

    def get_realtime_prices(self, symbols: list) -> Dict[str, Any]:
        """
        Fetches real-time snapshots from Alpaca (IEX) for a list of symbols.
        Returns a dict: { 'AAPL': {'price': 150.5, 'change_pct': 1.2, 'high': 151.0, 'low': 149.0} }
        """
        if not self.api or not symbols:
            return {}
        try:
            res = {}
            # Sadece NASDAQ / ABD hisselerini (kısa kodluları) filtrele
            valid_syms = [s for s in symbols if isinstance(s, str) and len(s) < 6]
            if not valid_syms:
                return {}
            
            # alpaca_trade_api v2 snapshot endpoint
            snapshots = self.api.get_snapshots(valid_syms)
            for sym, snap in snapshots.items():
                if snap and snap.latest_trade:
                    current_price = snap.latest_trade.p
                    prev_close = snap.prev_daily_bar.c if snap.prev_daily_bar else current_price
                    change_pct = ((current_price - prev_close) / prev_close * 100.0) if prev_close else 0.0
                    
                    res[sym] = {
                        "price": round(current_price, 2),
                        "change_pct": round(change_pct, 2),
                        "high": round(snap.daily_bar.h, 2) if snap.daily_bar else round(current_price, 2),
                        "low": round(snap.daily_bar.l, 2) if snap.daily_bar else round(current_price, 2)
                    }
            return res
        except Exception as e:
            logger.error(f"Alpaca Fetch Realtime Prices Failed: {e}")
            return {}

