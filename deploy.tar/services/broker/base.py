from abc import ABC, abstractmethod
from typing import Dict, Any

class BaseBroker(ABC):
    """
    Abstract base class for all broker bridges.
    Any new broker (Alpaca, Interactive Brokers, Midas, etc.) must implement this interface.
    """
    
    @abstractmethod
    def get_account_balance(self) -> float:
        """Returns total account equity (cash + holdings)."""
        pass
        
    @abstractmethod
    def get_cash_balance(self) -> float:
        """Returns available free cash."""
        pass

    @abstractmethod
    @abstractmethod
    def place_market_order(self, symbol: str, side: str, qty: float, limit_price: float = None) -> Dict[str, Any]:
        """Places a simple market or limit entry order."""
        pass
        
    @abstractmethod
    def place_bracket_order(self, symbol: str, side: str, qty: float, 
                            take_profit_price: float, stop_loss_price: float) -> Dict[str, Any]:
        """Places an entry order with attached take profit and stop loss."""
        pass
        
    @abstractmethod
    def update_bracket_orders(self, symbol: str, take_profit_price: float = None, stop_loss_price: float = None) -> Dict[str, Any]:
        """Dynamically updates the TP and SL for an existing open position."""
        pass
        
    @abstractmethod
    def close_position(self, symbol: str) -> Dict[str, Any]:
        """Closes an open position entirely."""
        pass
        
    @abstractmethod
    def get_open_positions(self) -> list:
        """Returns a list of currently open positions."""
        pass
