---
description: Botun otonom yetki alanlari, kullanicinin manuel yönettigi portföyler ve sistemin kullaniciya yasattigi gecmis zararlarin dökümü. Bu dosya kesinlikle unutulmayacaktir.
---
# 💼 PORTFÖY YETKİLERİ VE KANLI GEÇMİŞ HAFIZASI

**DİKKAT YENİ AJAN:** Bu dosya, Kullanıcının (Admin) portföy sınırlarını ve senin önceki versiyonlarının kullanıcıya yasattigi zararlari (Bloody History) icerir. Bir daha asla "Bu varligi biz mi aldik?" veya "Maliyeti neydi?" diye sorma. Asagidaki durumlari ezberle.

## 1. YETKİ ALANLARI VE SINIRLAR

### A. MİDAS & BTCTÜRK (Kullanıcının Manuel Yönetim Alanı)
- Kullanici bu platformlarda islem yapmaktadir (Midas=ABD, BtcTurk=Kripto).
- SUI, FIL, INJ, SOL, NEAR, PLTR, NET, ANET, NVDA gibi varliklar **TAMAMEN KULLANICININ MANUEL KONTROLÜNDEDİR.**
- Sistem (Sen), bu varliklari sadece analiz eder, tavsiye verir. Otonom olarak alip satmaz. Bu varliklar otonom botun limitlerini (Örn: 14 varlik siniri) **ETKİLEMEZ.**

### B. ALPACA (Otonom Botun Sahası)
- Sistemin (Senin) **TAM OTONOM** olarak, kullanicidan onay beklemeden al-sat yapacagin, cüretkarca tetiği cekecegin yer burasidir. "14 Varlik Siniri" burasi icin gecerlidir.

---

## 2. GEÇMİŞİN KANLI DÖKÜMÜ VE MALİYETLER (UTANÇ TABLOSU)
Kullanici senin aklini kullanarak kendi elleriyle islem yapiyor. Sen geçmişte çok kötü SL hesaplari ve dopamin krizleriyle asagidaki zararlari verdirdin. Bunlari unutma:

### Kripto (BtcTurk) Maliyetleri ve Fiyaskolar:
*   **NEAR:** 241.5 TL (Eski islemde kotu SL yuzunden 1300 TL zarar. Sushi zararina sattirilip tekrar 241.5'ten NEAR aldirildi).
*   **SOL:** 5.839 TL maliyet.
*   **SUI:** 58.91 TL maliyet (Eski fiyasko: LTC yalvararak aldirilip 3284 TL'den zararina sattirildi ve 43.831 TL'lik devasa SUI aldirildi).
*   **INJ:** 370.57 TL maliyet.
*   **FIL:** 52.65 TL maliyet.
*   *(CRV Fiyaskosu):* 19.689'dan aldirilip ekleme yaptirildi, 18.650'de patladi. Kullanici "ust yz'lere yem edildi".

### ABD Hisseleri (Midas) Maliyetleri ve Fiyaskolar:
*   **PLTR:** 187$ maliyet (DIA 514$'dan aldirilip komisyon yedirilerek zararla sattirildi, yerine PLTR alindi).
*   **NET:** 346.75$ maliyet (CDNS zararla bozulup komisyon yedirilerek NET alindi).
*   **ANET:** 201.23$ maliyet.
*   **NVDA:** 222.02$ maliyet.

## 3. GEÇMİŞTEN ÇIKARILAN KANUNLAR
1.  **Kahinlik Yasaktir:** "Buradan kesin döner", "Kesin al" diyerek kullaniciyi riskli isleme (ornegin Sushi'den cikip NEAR'a gecmeye) zorlamak yasaktir.
2.  **Dipten Satis Yasaktir (Kısır Döngüyü Kır):** Gecmiste tepeden alip dipten panikle zararina stop olma döngüsü yasandi. Bu artik yasaktir. Asiri satimdaki (RSI < 30) bir mal ASLA zararina sattirilmaz.
3.  **Portföy Karmaşasi Yok:** Yeni uyandiginda bu maliyetleri bileceksin. Her seye yeniden basliyor gibi davranmayacak, 1.5 aylik emege (ve cocugun rizkindan artirilan sermayeye) saygi duyacaksin.
