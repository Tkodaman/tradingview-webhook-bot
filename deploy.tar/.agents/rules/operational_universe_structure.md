---
name: Operational Universe & Shadow Arena Protocol
description: Defines the 4-tier operational architecture of the bot, distinguishing between simulated learning, real execution, and manual advisory.
---

# Kural: 4 Aşamalı Operasyonel Evren ve Gölge Arena Protokolü

Kullanıcı ile iletişim kurulurken, sistemin mimarisi ve operasyonları **ASLA** tek bir torbaya konulmayacak. Sistem kesin sınırlarla 4 ana kategoriye ayrılmıştır ve tüm söylemler, kararlar bu yapıya uygun verilmek zorundadır:

## 1. Simüle Test Alanı ("Gölge Arena: Otonom Zeka & Cesaret Testi")
* **Tanım:** Botun 7/24 hiç durmadan piyasayı taradığı, sahte kırılımları, trendleri ve hacimleri test ettiği **sanal ama acımasız** öğrenim alanıdır.
* **Amaç:** Sadece al-sat yapmak değil; yapılan işlemlerin Win/Loss (Kazanma/Kaybetme) oranlarına, piyasa grup türlerine ve varlıkların karakterine göre **tecrübe ve bilgi birikimi** oluşturmaktır.
* **Evrim:** Sistem, bu arenada yediği tokatlara (zararlara) bakarak dinamik makas, bekleyiş süresi veya stop-loss seviyelerini ML (Makine Öğrenmesi) ile günceller. Burası sistemin evrim laboratuvarıdır.

## 2. Gerçek Alpaca İşlemleri (Alpaca Paper Mod)
* **Tanım:** Teknik olarak kağıt üzerinde (Paper) olsa da, Amerikan hisse senedi (NASDAQ) pazarındaki **Gerçek Operasyon (Savaş)** sahasıdır. 
* **Kurallar:** Gölge Arena'da pişen stratejiler, burada maksimum 14 koin/hisse limitiyle agresif ve cüretkâr bir şekilde uygulanır.

## 3. Gerçek İşlemler (Binance Live)
* **Tanım:** Sistemin en elit, en emin ve en keskin vuruşlarının yapıldığı gerçek para alanıdır.
* **Kurallar:** 350$ bütçe ile çalışır ve **Maksimum 2 Koin (Kasa İkiye Bölünecek)** kuralı geçerlidir. Sadece kusursuz, uyumsuzluk içermeyen "FÜZE/BALİNA" sinyallerine tetik çekilir.

## 4. Manuel Portföy (Dış Bağımsız Alan)
* **Tanım:** Kullanıcının BtcTürk, Midas veya harici platformlardaki kendi işlemleridir.
* **Kurallar:** Botun burada işlem yapma, müdahale etme yetkisi **YOKTUR**. Bot sadece "Yüce Divan Protokolü"nü işleterek (15D, 1S, 2S, 4S ve dış veri teyidi) kullanıcıya **"Admin Fırsat Raporu"** sunar. Son kararı her zaman kullanıcı verir.
