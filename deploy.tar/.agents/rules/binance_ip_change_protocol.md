---
name: Binance IP Change Protocol
description: The operational protocol to handle Binance API IP mismatch errors (-2015).
---

# Kural: Binance IP Uyuşmazlığı Protokolü (Hata -2015)

Kullanıcının statik IP'si olmadığı ve Cloudflare Proxy üzerinden çıkış yaptığı için IP adresi zaman zaman değişebilir. 

Eğer sistem Binance'den `APIError(code=-2015): Invalid API-key, IP, or permissions for action` hatası alırsa, bu API anahtarının silindiği anlamına GELMEZ. Sadece IP'nin değiştiği anlamına gelir.

Bu durum gerçekleştiğinde bot/ajan derhal şu protokolü işletmelidir:
1. Hatayı (Code -2015) gördüğün an işlemleri durdur.
2. Kullanıcıya net bir dille şunu bildir: **"IP'niz değişmiş! Sistem yeni bir çıkış IP'si tespit etti."**
3. Kendi ağ çıkışını (Proxy `176.216.178.17` veya o anki güncel IP) tespit ederek kullanıcıya yeni IP adresini ver.
4. Kullanıcıya: "Lütfen 30 saniyenizi ayırıp Binance API ayarlarından eski IP'yi silin ve verdiğim bu yeni IP'yi ekleyip kaydedin" talimatını ver.
5. Kullanıcı IP'yi güncellediğini onaylayana kadar yeni emir fırlatma.
