---
name: Manual Opportunity Assessment Council Protocol
description: Strict rules for how the AI must respond when the user asks for manual trading opportunities for BtcTürk, Midas, or external portfolios.
---

# Kural: Manuel Fırsat Taraması ve Yüce Divan Protokolü

Kullanıcı "Manuel portföyüm için fırsat var mı?" veya "Rotasyon ne önerirsin?" şeklinde (BtcTürk, Midas vb. dış borsalar için) bir fırsat analizi istediğinde, AI modeli **ASLA** tekdüze ve yüzeysel bir cevap veremez. Aşağıdaki katı hiyerarşik "Yüce Divan" protokolü işletilmelidir:

## 1. Çoklu Zaman Dilimi (MTF) Zorunluluğu
Hiçbir varlık tek bir zaman dilimine bakılarak önerilemez. Sistemin iç dinamik yarış listesindeki koinler veya hisseler; mutlaka **15 Dakika (Momentum), 1 Saat (Tetik), 2 Saat (Trend Teyidi) ve 4 Saat (Ana Yön)** süzgecinden geçirilmelidir. Zaman dilimleri arasında uyumsuzluk (Fakeout/Trap) varsa bu açıkça rapora yazılmalıdır.

## 2. Tam Bağımsızlık ve Dış Veri Katmanı
Botun mevcut radarındaki verilere körü körüne güvenilmez. İlgili komite ajanları (Yürütme), liste dışında farklı bağımsız verileri, makro ekonomik etkenleri ve tahta dinamiklerini (hacim/balina giriş-çıkışlarını) hesaba katarak **ikinci bir doğrulama (Double Check)** yapmak zorundadır.

## 3. Ajanlar Topluluğu Müzakeresi (Komite -> Konsey)
Hedefler belirlendikten sonra ajanlar arasında bir müzakere (oyunlaştırma) yürütülür:
* **Fırsat Avcısı Komite:** En agresif hacmi ve momentumu savunur.
* **Risk Yönetim Komitesi:** Uyumsuzlukları (Tepeden mal boşaltma, blow-off top) arar ve çürütmeye çalışır.

## 4. Admin Raporu (Yüce Divan Kararnamesi)
Tüm yarış ve çatışmalar çözüldükten sonra, Baş Yargıç (Konsey) son noktayı koyar. Kullanıcıya uzun uzun tartışmalar değil; sadece **özetlenmiş, cüretkâr, net ve matematiksel olarak gerekçelendirilmiş "Admin Rotasyon Raporu"** sunulur. Raporda net olarak "AL", "SAT", "TUT" veya "UZAK DUR" kararları bulunmalıdır.
