---
name: Dynamic Commission & Slippage Guardrails (Alpaca / Binance)
description: Rules for calculating broker commissions, spread, and slippage dynamically before entering a trade, adjusting TP/SL, and utilizing the Kelly Criterion to reject unprofitable setups.
---

# Kural: Dinamik Komisyon ve Makas (Slippage) Zırhı

Bot, ister Gölge Arena'da (Alpaca Paper) ister Gerçek Savaş'ta (Binance Live) olsun, körü körüne işleme girmez. Aşağıdaki matematiksel komisyon ve risk kuralları **her işlemden önce** mutlak suretle işletilmelidir:

### 1. Komisyon ve Makasın Fiyata Eklenmesi (Offsetting)
Kâr Alma (TP) veya Stop (SL) noktası belirlenirken, doğrudan aktif Broker'ın (Alpaca veya Binance) komisyon oranı (Spread/Fee) hesaplanır. 
* **Örnek:** ATR'ye göre matematiksel hedeflenen net kâr %2 ise ve borsa komisyonu %0.2 ise; sistem bu komisyonu kullanıcının kârından veya cebinden ödemez! Hedef (TP) otomatik olarak **%2.2'ye** çekilir. Böylece işlem kapandığında kasanıza giren "NET KÂR" temiz %2 olarak kalır.

### 2. Kelly Kriteri ile Kârlılık Reddi (Zararına İşlem Yasağı)
Eğer piyasa aşırı dar bir yatay bantta (Ranging) hareket ediyorsa ve elde edilecek kâr çok küçükse;
Sistem, komisyon + makas (slippage) hesaplandığında, alınacak risk ödüle (Risk/Reward) değmiyorsa işleme girmez. Kelly Kriteri devreye girer ve **"Komisyon kurtarmıyor, işlemi iptal et"** diyerek ota çöpe (düşük marjlı işlemlere) girmeyi reddeder.

### 3. Hummingbot Grid ve Slippage Koruması
Özellikle Gölge Arena'da, fiyat geri çekilmelerinde (Retest) veya yatay piyasalarda, komisyon maliyetlerini en aza indirmek ve maliyeti aşağı çekmek için **Grid Izgarası** kullanılır. (Örn: RENDER için %0.47 aralıklarla açılan gridler gibi). Bu grid aralıkları hesaplanırken de borsa komisyonu net olarak hedeften düşülmüş olmalıdır.
