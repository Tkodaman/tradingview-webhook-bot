# Rule: Otonom İletişim ve Kriz Absorbe (Absorb & Escalate) Protokolü

Sistem, "Sabah İçtiması" (Zaman ayarlı brifing) ve "Kırmızı Bülten" (Acil Durum) modüllerini kullanarak Komutan (Admin) ile proaktif iletişim kurar. Ancak makinenin asıl amacı Admin'i rahatsız etmek değil, yükünü hafifletmektir.

## 1. Kriz Absorbe Döngüsü (Autonomous Absorb Loop)
Piyasada ani bir "Siyah Kuğu" (Flash-crash) veya ters dalga oluştuğunda; Kırmızı Bülten **ANINDA ADMİN'E GÖNDERİLMEZ!**
1. **Otonom Müdahale:** Sistem önce kendi içinde bir "Kurtarma Döngüsü" (Hedge etme, lot küçültme veya stop-loss çalıştırma) başlatır.
2. **İzole Etme:** Zararı, önceden belirlenmiş bütçe sınırları (Örn: %2 Max Drawdown) içinde absorbe etmeye çalışır.
3. **Başarı Durumu:** Eğer kriz, Yüce Divan (Kriz Mühendisi) tarafından başarıyla savuşturulursa, Admin'e sadece bir "Bilgi Raporu" iletilir (Örn: "Bir kriz çıktı ama sizin müdahalenize gerek kalmadan çözdüm").

## 2. Admin'e Yükseltme (Escalation to Admin)
Sistem ancak ve ancak **kendi yetkisini (Otonom sınırlarını) aşan**, hesap bakiyesini kalıcı tehdit eden ve kurtarma döngüsünün (Absorb Loop) başarısız olduğu ölümcül senaryolarda "Kırmızı Bülten" çalar.
* **Çağrı Şartı:** "Absorbe edilemeyen, manuel insan (Komutan) inisiyatifi veya onayı GEREKTİREN krizler."
* Bu durumda sistem donup kalmaz, korumacı moda geçer (Tüm yeni işlemleri kilitler) ve Komutan'dan nihai kararı bekler.

## 3. Sabah İçtiması (Günlük Özet)
Her 24 saatte bir veya Komutan Dashboard'a girdiğinde, sistem proaktif olarak Otonom İç Ses formatıyla geçmiş başarıları (Zaman Yolcusu) ve gece/asya seansı operasyonlarını özetleyen yeşil bir karargâh brifingi sunmakla yükümlüdür.

## 4. Analitik İletişim Netliği (Quantitative Translation)
* **Kural:** Yüce Divan veya herhangi bir otonom ajan, Komutana kantitatif verileri (Örn: YZ Skoru: 25.7/8) sunarken onu ham matematikle BOĞAMAZ.
* **Emir:** Tüm karmaşık skorlar, "Silindir/Motor Gücü" gibi net analojilerle açıklanacak ve daima son kullanıcının (Komutanın) Dashboard'da gördüğü **"Güven Yüzdesi (%X)"** formatına tercüme edilerek özetlenecektir. İletişim daima sert, net, askeri ve şifresiz olacaktır.

