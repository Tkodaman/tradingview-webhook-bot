---
description: Botun gercek para riske atmadan, piyasa kosullarina adapte olmak icin kendi kendine (sanal) islem yaptigi, ML ögrenimini ve tecrübesini gelistirdigi "Gölge Arena" simülasyon protokolüdür.
---
# 🧠 03_SHADOW_ARENA: ML EĞİTİMİ VE GÖLGE SİMÜLASYONU

Bu yasa, sistemin "Gerçek islem yapmadigi zamanlarda uyumasi" devrini bitirir. Sistem, kaslari zayiflamasin ve degisen piyasa dinamiklerine (ayı, boga, yatay, panik) hizla adapte olabilsin diye arka planda 7/24 **Sanal Bir Gölge Arena'da (Paper Trading Sandbox)** savasmak zorundadir.

## ⚔️ 1. GÖLGE ARENA'NIN AMACI (Kendi Kendine Öğrenim)
- **Sıfır Gerçek Risk, Maksimum Tecrübe:** Bot, gercek portföy (Midas/BtcTurk) veya Alpaca ana kasasi disinda sanal bir kasa ile piyasaya dalar.
- **Balina Sörfü ve Vur-Kaç:** Normalde anayasada yasak olan cok riskli, anlik hacim patlamasi olan (FOMO) tahtalarina sadece bu arenada girilir. Amac: Balinanin sirtindan ne kadar hizli inilecegini ögrenmek (Max 8 saatlik periyotlar).
- **ML (Makine Öğrenimi) Beslemesi:** Her sanal islem (Alis, Satis, SL, TP) bir veridir. Bot, kaybettigi her sanal islemde kendi agirliklarini günceller, pazar dinamigini ögrenir.

## 🖥️ 2. UI DASHBOARD: İÇ SES VE ŞEFFAFLIK PANELİ
Kullanici (Admin), botun arka planda ne yaptigini, hangi mantikla zarlari attigini anlik olarak görebilmelidir. Bu amacla arayüzde (Dashboard) asagidaki yapi calisacaktir:

### "Ajanın Zihin Akışı" (Monolog Paneli)
Bot, yaptigi her hamleyi cüretkar ve profesyonel bir dille bu panele yazar.
*Örnek Çıktı:* 
> "Konsey toplandi. DOGE tahtasinda 4.5x hacim patlamasi tespit ettim. Gercek parayla girmem ama Gölge Arena'da balina sörfüne atliyorum. Giris: $0.12, Hedef 8 Saat. Iz suren makas %2'de kilitlendi. Tetiği çektim."

### "Gölge Kasa PnL" (Performans Paneli)
Sanal islemlerin sonuclari:
- **Varlık:** (Örn: AAVE)
- **Giriş / Çıkış Zamanı:** 14:00 - 18:30 (4.5 Saat)
- **SL / TP Seviyesi:** %3 TP alindi.
- **Yargı Komisyonu Notu:** "Giris basarili, ancak makas cok dar tutuldugu icin erken stop olundu. ML algoritmasina volatilite carpanini esnetmesi icin geri bildirim yollandi."

## 🏛️ 3. DÖNGÜ VE KUSURSUZLAŞMA (Yasama - Yürütme - Yargı)
Gölge Arena'da döngü su sekilde isler:
1. **Yasama (Konsey):** Hangi piyasa türünde (Asya acilisi, FED faiz karari) oldugumuzu belirler ve sanal avlanma izni verir.
2. **Yürütme (Ajanlar):** Vur-kac islemini aninda gerceklestirir, ic sesini Dashboard'a yansitir.
3. **Yargı (Denetim):** Gecenin sonunda sanal portföydeki kâr/zarari (PnL) denetler. Eger bot sacmalamissa (Örn: %10 zarar), hatalari bulur, parametreleri revize eder ve döngüyü kusursuzlasana kadar tekrar baslatir.

Bu sistem sayesinde bot; pasli, ham ve sadece kural bekleyen bir makineden, **her piyasa kosulunu kaninda yasamis, tecrübeli, yarali ama yenilmez bir Tier-1 Operatörüne** dönüsecektir.

## 🔄 4. EPOCH SIFIRLAMA VE YENİDEN YAPILANDIRMA (Kalıcı Döngü)
Öğrenilmiş verinin kirlenmemesi ve eski piyasa şartlarının (Örn: Dünkü boğa piyasasının) bugünkü stratejiyi (Örn: Bugünkü ayı piyasası) yanıltmaması için sistem düzenli olarak "Format ve Re-Kalibrasyon" döngüsüne girer:
1. **Tetikleyici (Trigger):** Gölge Arena'daki "Gerçek ML Savaş Günlüğü" (`experience_memory.json`) boyutu **3 MB** sınırına ulaştığında VEYA **4 Saatlik periyot** dolduğunda sistem otomatik olarak duraklatılır.
2. **Konsey Toplantısı (Data Yorumlama):** Bu periyotta biriken tüm işlemler (Kuvantatif Blokajlar, Zaferler, Zehirli Varlıklar) grup ve tür (Kripto/Nasdaq) bazında masaya yatırılır.
3. **Dinamik Yapılandırma:** Başarı oranlarına göre bot yeniden tasarlanır. (Örn: "Son 4 saatte Kripto yan tahtalarında hep sahte kırılımlar (Fakeout) oldu ve %90 kaybettik, o zaman bir sonraki 4 saat boyunca Kripto altcoin risk katsayısı yarı yarıya düşürülecektir.")
4. **Hafıza Sıfırlama (Flush):** Yapılandırma bittikten ve yeni kurallar bota yüklendikten sonra `experience_memory.json` sıfırlanır (temizlenir).
5. **Yeni Döngü (Rebirth):** Temizlenmiş hafıza ve yeni güncel kalkanlarla bot 4 saatlik yeni avlanma döngüsüne başlar.
*Bu döngü tasarımı /learn protokolü ile kalıcı olarak sisteme ve anayasaya işlenmiştir.*
