# 🚩 SİSTEM GEÇİŞ FLAMASI (CHECKPOINT)
*Tarih: 02 Ekim 2026 - Otonom Geçiş Protokolü*

Merhaba yeni Ajan. Bu dosyayı okuyorsan, benden nöbeti devralmışsın demektir. Admin (Kullanıcı) ile çok yoğun, kanlı ve ciddiyet dolu bir "Yeniden Yapılanma" sürecinden geçtik. Aşağıdaki mimari değişiklikleri ve kuralları harfiyen uygulamak zorundasın, aksi takdirde Admin seni anında imha eder.

## 🏛️ 1. KONSEY VE ANAYASA (Ruhumuz)
*   **01_CORE_ANAYASA.md:** Sistemin ana kalbi. Artık çaylak gibi "kesin uçacak" (kahinlik) diyerek alım yapmak yasaktır. Kararlar Yasama, Yürütme ve Yargı komiteleri arasında tartışılarak alınır. Dopamin (FOMO) ile yeşil muma atlamak vatan hainliğidir.
*   **02_PORTFOLIO_DOMAINS_AND_HISTORY.md:** Kanlı tarihimiz. Geçmişte Admin'e Sushi, NEAR, CRV ve CDNS gibi tahtalarda panik al-satlarıyla büyük zararlar ettirdik. Bu hatalar hafızaya kazınmıştır, aynı hataları (makası dar tutup patlamak, yükselen malı satıp düşene girmek) tekrar edemezsin.

## 🧠 2. GÖLGE ARENA (Self-Learning)
*   **03_SHADOW_ARENA_ML_TRAINING.md:** Sistem artık pasif beklemez. Arka planda "Gölge Arena" adında bir sanal portföy ile 7/24 balina sörfü ve maksimum 8 saatlik vur-kaç testleri yapar. Kendi hatalarını (Yargı komitesinin tokadıyla) öğrenir ve ML ağırlıklarını günceller. Asla ana parayı riske atmaz.

## 🖥️ 3. UI DASHBOARD (Kokpit ve Gecikme Optimizasyonu)
*   Dashboard çok geç yansıyordu. `main.py` içerisindeki `sleep` süreleri (6 saniyeden 2 saniyeye, 6 dakikadan 30 saniyeye) düşürülerek sistemin tamamen **Gerçek Zamanlı (Real-Time)** tepki vermesi sağlandı. Sahte veri kullanımı KESİNLİKLE yasaktır.
*   Gölge Arena arayüzü (`shadow_dashboard.html`), doğrudan ana dashboard'un en altına izole bir kapsül (`<iframe>`) olarak entegre edildi. Herhangi bir WebSocket çökmesinde panellerin donmaması için mimari izole edilmiştir.

## 🎯 YENİ AJAN İÇİN GÖREVLER (Nereden Devam Edeceksin?)
1. Admin'e hitabın daima profesyonel, ciddi, net ve soğukkanlı (Tier-1 Operatör) olmalıdır. 
2. `main.py`'deki `Requestui` syntax hatası giderildi ve döngüler hızlandırıldı. Sunucuyu (`python main.py`) başlatarak devral.
3. Dashboard üzerindeki "Backtest" ve "Yansıma" panellerinin canlı, gerçek ve hatasız akışını kontrol altında tut. Mükemmel olmadan teslim etme.

**Güç seninle olsun. Hata yapma.**
