# Rule: Kusursuz İnfaz ve Yüce Divan Hiyerarşisi (Supreme Execution Protocol)

Bu protokol, Otonom Botun (PM2 Motoru) ve Yüce Divan'ın nihai yetki sınırlarını, acil durum şalterlerini ve tahta korumalarını belirler. Tüm kodlamalarda ve karar mekanizmalarında bu yasa geçerlidir.

## 1. Mutlak Hiyerarşi (The Ultimate Boss)
* **Kural:** TradingView'den gelen Webhook sinyalleri veya diğer dış alarmlar sadece birer "Tavsiye" niteliğindedir. 
* **Emir:** Milisaniyelik çakışmalarda (Deadlock) veya zıt yönlü sinyallerde **YÜCE DİVAN'IN (Otonom Konseyin) KARARI ESASTIR.** Yüce Divan "VETO" (Sat veya İptal) dediği anda, TradingView'in "Al" sinyali yok sayılır ve çöpe atılır. Hiyerarşinin mutlak patronu Yüce Divan'dır.

## 2. Kırmızı Bülten ve Ölü Adam Şalteri (Dead Man's Switch)
* **Kural:** Kriz Absorbe döngüsü başarısız olup Kırmızı Bülten çalındığında ve Admin'e (Komutan) ulaşılamadığında sistem donup kalamaz.
* **Emir:** Kırmızı Bülten anından itibaren sayaç başlar. Eğer **3 DAKİKA** içinde Komutan'dan manuel bir müdahale veya iptal emri gelmezse ve açık pozisyonlardaki ZARAR önceden tanımlanmış kritik eşiği (Örn: %3) aşmaya devam ediyorsa; Sistem **"ÖLÜ ADAM ŞALTERİNİ (Kill Switch)"** çeker. Tüm açık pozisyonlar acımasızca (zararına bakılmaksızın) Piyasa Emriyle satılıp sistem NAKDE döner. Zaiyat minimumda kesilir.

## 3. Tahta Derinliği (Order Book) ve Kayma (Slippage) Kalkanı
* **Kural:** Gölge Arena'daki (Paper Trading) kağıt üstü rakamlara aldanıp körü körüne yüklü alım/satım yapılamaz.
* **Emir:** İnfaz emri Broker'a (Alpaca/Binance) gönderilmeden hemen önce (Keskin Nişancı tarafından) tahta likiditesi kontrol edilir. Eğer hedeflenen lot büyüklüğü fiyatı %0.5'ten fazla kaydıracaksa (Market Impact), emir anında "Parçalı Limit Emri (Iceberg/TWAP)" formatına dönüştürülür veya lot otomatik olarak yarıya düşürülür. Kötü fiyattan işlem açılması yasaktır.

## 4. TIER-1 SİBER ZIRHLAR (Nihai Güvenlik Çözümleri)
* **Kör Bulut (Hard-Stop) Çözümü:** Tüm işlemler (Alım yapıldığı saniye) Alpaca/Binance'in kendi sunucularına **"OCO Bracket (One-Cancels-the-Other) Hard Stop/TP"** olarak gönderilmek ZORUNDADIR. VPS (Sunucu) veya bot siber saldırıya uğrar, çöker veya interneti kesilirse; borsa işlemleri kendi sunucusunda otomatik olarak SL veya TP ile kapatır. Bot hafızasına (Soft-Stop) güvenilmez.
* **Otonom Halüsinasyon (Çapraz Teyit) Çözümü:** Yüce Divan (LLM) karar verirken sadece haberin başlığına inanamaz! Haberin "Zaman Damgası" (Son 4 saatte mi?) ve Kantitatif veriyle eşleşmesi (Haber kötü ama hisse yükseliyor mu?) zorunludur. Matematikle uyuşmayan her haber "Manipülasyon" (Fake News) kabul edilip çöpe atılır.
* **API Ambargosu ve Siyah Kuğu Çözümü:** Acil bir çöküşte, bot asla hisseleri teker teker satıp borsanın "API Rate Limit" sınırına çarpmaz. Kriz Mühendisi doğrudan **"close_all_positions()"** komutuyla (Tek API çağrısı) tüm mermiyi (portföyü) aynı saniye nakde çevirir. API banlanma riski sıfırlanır.

