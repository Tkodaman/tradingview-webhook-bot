---
name: portfolio-risk-guardrails
description: "Use when sizing positions, checking portfolio exposure, correlation, daily loss, drawdown, consecutive losses, kill switches, or reviewing whether an order can be allowed."
---

# Portfolio Risk Guardrails

Bir sinyal iyi olsa bile portföy riski izin vermiyorsa işlem açılmaz. Sermaye korunması model skorundan üstündür.

## Merkezi Limitler
- İşlem başı risk: account equity'nin sabit küçük yüzdesi.
- Maksimum nominal bütçe: tek merkezi config kaynağından.
- Günlük zarar limiti ve maksimum drawdown.
- Piyasa ve korelasyon grubu başına maruziyet.
- Aynı sembolde tek açık pozisyon.
- Ardışık kayıp devre kesici.
- Broker/local reconciliation başarısızsa yeni işlem yok.

## Position Sizing
`qty = allowed_risk_amount / stop_distance` ile hesapla. Sonra spread, fee, slippage, minimum lot, nominal cap ve portföy maruziyetini uygula. Sonuç sınırların dışındaysa lot küçült veya `NO-TRADE` döndür.

## Koruma Davranışı
- Stop/target yoksa emir reddedilir.
- Risk hesabı belirsizse lot artırılmaz.
- LLM hiçbir merkezi limiti değiştiremez.
- AGGRESSIVE/SNIPER modu hacim, stop veya günlük zarar korumasını gevşetemez.
- Desync, stale data, macro shock veya toxic-memory durumunda kill-switch uygulanır.

## Çıktı
`risk_amount`, `nominal_value`, `portfolio_exposure`, `correlation_exposure`, `daily_loss`, `drawdown`, `sizing_qty`, `hard_limits`, `decision_gate` alanlarını döndür.
