---
name: Premium Crypto AI Trading (SOTA)
description: State-of-the-Art (FinRL/FreqAI) inspired Crypto Trading logic. Focuses heavily on Volatility, Volume Spikes, and extremely tight risk-management guardrails.
author: System
---

# Premium Crypto AI Trading (SOTA)

Bu yetenek (skill) dosyası, 2026 yılının önde gelen (State-of-the-Art) yapay zeka kripto botlarının (FinRL, Freqtrade, TorchTrade) stratejilerini referans alır. Borsa (BIST/NASDAQ) algoritmaları kriptoda başarısız olduğundan, kripto için izole ve farklı bir zihniyet gerektirir.

## Temel Felsefe (Sıfır Tolerans)
Kripto piyasasında "Hisse Senedi" sabrı yoktur. Varlık bir anda %20 değer kaybedebilir. 
Ana kural: **Sermaye Koruması (Capital Preservation) Kâr Etmekten Üstündür.**

## Karar Alma Kriterleri (FreqAI ML-Benzeri Skorlama)
Premium Ajan, klasik RSI/MACD kesişimlerinden ziyade şunlara odaklanır:
1. **Oynaklık (Volatility / ATR):** ATR çok düşükse kripto ölüdür, girilmez. ATR çok yüksekse risklidir, makas geniş tutulmalı ama stop sıkı olmalıdır.
2. **Hacim Patlamaları (Volume Spikes):** Kriptoda hacim olmadan fiyat hareketi fake (sahte) sayılır. Hacim oranı > 2.0 değilse şüpheyle yaklaşılır.
3. **Fiyat Momentumu:** Düşen bıçak tutulmaz. Sadece "Higher High" (Daha yüksek tepe) yapan momentuma girilir.

## Güvenlik Kalkanları (Guardrails)
1. **Hard Stop-Loss Limit:** İşlem açıldığında, eğer zararı %2'yi anlık geçerse ajan (hiçbir trendin dönmesini beklemeden) derhal piyasadan çıkar.
2. **Trailing Stop (İzleyen Stop):** Kâr %2'yi geçtiği an, stop noktası anında başa baş (Break-Even) veya kârda bir noktaya taşınır. Kriptoda kâr asla geri verilmez.
3. **Toksik Filtre Saygısı:** `experience_memory_engine` tarafından "Toksik" olarak işaretlenmiş hiçbir varlığa girilmez.

## LLM Kullanımı
LLM, fiyat analizi yapmak yerine; "Sinyalin arkasında bir Hype (Sosyal Duyarlılık / Haber) var mı?" sorusuna yanıt vermelidir.
