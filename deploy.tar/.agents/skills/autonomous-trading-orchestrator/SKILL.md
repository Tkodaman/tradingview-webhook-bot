---
name: autonomous-trading-orchestrator
description: "Use when producing an autonomous trading decision, ranking opportunities, reviewing a TradingView signal, or coordinating data quality, regime, risk, execution, memory, and backtest skills."
---

# Autonomous Trading Orchestrator

Bu skill diğer trading skill'lerinin karar sırasını ve geçiş kapılarını yönetir. Amaç işlem sayısını artırmak değil, sermaye korunurken doğrulanmış avantajı kaçırmamaktır.

## Zorunlu Akış (Konsey + Avcı Hiyerarşisi)
1. **Konsey Değerlendirmesi (Market Router):** Tüm varlıklar Konsey tarafından (Hacim, RSI, CMF, ADX, Stoch) detaylıca analiz edilir.
2. **WMA +2 Puanlaması (Kaos Engelleyici):** Fiyat veya Hacim patlamalarına anında atlanmaz. Geçmiş 3 analiz sonucunun Ağırlıklı Ortalaması (WMA) alınarak sahte pumplar süzülür.
3. **VIP Fırsat Sıralaması (Opportunity Ranking):** Momentum, volume, relative strength, VWAP/EMA ve multi-timeframe uyumunu geçen varlıklar, WMA skoruna göre en yüksekten düşüğe doğru VIP (Top-Down) listesine dizilir.
4. **Otonom Avcı (Autonomous Engine):** Avcı motoru piyasayı 'rastgele' taramaz. DOĞRUDAN Konseyin hazırladığı VIP listesindeki en yüksek puanlıdan (Top 1'den) taramaya başlar.
5. **Aşamalı Alım (Pacing) Zırhı:** Avcı, VIP listeden seçip girdiği ilk pozisyonun ardından EN AZ 15 DAKİKA pusu moduna (cooldown/pacing) geçer. Fırsatlar tek tek, süzülerek toplanır.
6. **Bütçe ve Limit Yalıtımı:** Kripto/Binance (ör: $1600 limit, maks 6 pozisyon) ile Alpaca/Hisse bütçeleri tamamen ayrı havuzlarda yönetilir.
7. **Karar ve İcra (Gölge veya Gerçek):** `BUY`, `SELL`, `HOLD`, `WAIT` kararları, sistemin moduna göre 🥷 (Gölge) veya 💼 (Gerçek) rozetleriyle Seyir Defterine (Journal) işlenir.

## Gölgeden Canlıya Terfi Protokolü (Shadow-to-Live Promotion)
Gölge modda (PAPER) açılan pozisyonların kapanıp tecrübe edinilmesi ana esastır. **ANCAK:**
- **Muazzam Uyum (Kusursuz Veri):** Eğer Gölgedeki bir varlığın anlık verileri Konseyin WMA+2, Hacim ve Makro filtreleriyle KUSURSUZ ölçüde örtüşüyorsa; YZ Otonom Avcı, fırsatı kaçırmamak adına Gölgedeki işlemin kapanmasını (satılmasını) BEKLEMEDEN bizzat inisiyatif alarak doğrudan GERÇEK (LIVE) alım yapabilir.
- **Şüphe ve Tedbir:** Eğer piyasa koşullarında ufak bir belirsizlik, makro (VIX) korkusu veya fitilli sahte kırılım şüphesi varsa; o varlık kesinlikle "Tecrübe" hanesine işlenip (satılana kadar) izlenmeye devam eder. Şüphe varsa Gerçek Alım yapılmaz.

## Fırsat Kaçırmama Kuralı
Teyitsiz erken giriş yerine koşullu alarm üret:
- breakout seviyesi
- retest seviyesi
- hacim eşiği
- geçersizlik seviyesi
- veri tazeliği süresi

Böylece sinyal kaçırılmaz, fakat teyit gelmeden sermaye riske atılmaz.

## Yasaklar
- Tüm pozisyon limitini (cephaneyi) tek seferde aynı dakika içinde doldurmak. (Pacing/5 dk Zırhı ihlal edilemez).
- Konsey'in belirlediği WMA VIP sıralamasını görmezden gelip rastgele varlık avlamak.
- Eksik veriyi varsayılan değerle doldurup BUY üretme.
- LLM güvenini piyasa olasılığı gibi sunma.
- Broker fill olmadan OPEN gösterme.
- PAPER doğrulaması olmadan LIVE önermeme.
- Kullanıcı onayı olmadan canlı moda veya risk gevşetmeye geçmeme.

## Çıktı Sözleşmesi
Her kararda şu alanlar bulunur:
- `decision`
- `asset`, `market`, `timeframe`
- `data_timestamp`, `data_age_seconds`, `data_quality`
- `regime`, `entry_context`, `confirmation_required`
- `invalidation`, `hard_stop`, `target`, `risk_reward`
- `risk_amount`, `size_limit`, `portfolio_exposure`
- `execution_state`, `broker_status`
- `facts`, `assumptions`, `uncertainties`
- `reason`, `next_check_at`

Kanıt yetersizse sonuç `NO-TRADE` olmalıdır.
