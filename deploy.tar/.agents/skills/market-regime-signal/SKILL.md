---
name: market-regime-signal
description: "Use when ranking opportunities, detecting trend/range/volatility regimes, validating momentum breakouts, avoiding falling knives, or combining multi-timeframe technical signals."
---

# Market Regime and Signal Quality

Amaç daha fazla işlem değil, rejime uygun ve teyitli fırsatları seçmektir. LLM fiyatı tahmin etmez; teknik sinyalin bağlamını ve haber/hype riskini yorumlar.

## Rejim Sınıfları
- Trend: EMA yapısı, ADX, higher-high/lower-low ve VWAP uyumu.
- Range: düşük ADX, mean-reversion sınırları ve breakout bekleme.
- Volatile: ATR, spread ve gap riski; pozisyon küçültme veya NO-TRADE.
- Shock: flash crash, makro olay, veri çatışması; yeni girişleri dondur.

## Fırsat Sıralama
1. Üst timeframe yönüyle aynı yönde ol.
2. Hacim oranı ve fiyat hareketi birlikte teyit edilsin.
3. RSI tek başına sinyal sayılmasın.
4. VWAP, EMA, Supertrend ve momentum çelişkilerini açıkça raporla.
5. Breakout sonrası retest olmadan fiyat kovalanmasın.
6. Toksik hafıza veya negatif korelasyon sinyali varsa sıradan çıkar.

## Zorunlu Trade Çıktısı
- `BUY`, `SELL`, `HOLD`, `WAIT` veya `NO-TRADE`
- Giriş bölgesi ve teyit koşulu
- Geçersizlik seviyesi
- Hard stop, hedef, R:R
- Volatilite ve spread notu
- Sinyal güveni ile örneklem büyüklüğü

Teknik teyit yoksa sonuç `NO-TRADE` olur; tahmini kesinlik dili kullanılmaz.
