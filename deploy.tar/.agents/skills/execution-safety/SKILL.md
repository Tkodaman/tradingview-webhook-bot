---
name: execution-safety
description: "Use when routing broker orders, validating fills, handling retries, checking spread/slippage, reconciling local and broker state, or preventing duplicate and phantom positions."
---

# Execution Safety

Sinyal oluşması emir gerçekleştiği anlamına gelmez. Sistem `SUBMITTED`, `ACKNOWLEDGED`, `PARTIALLY_FILLED`, `FILLED`, `REJECTED`, `CANCELLED` ve `UNKNOWN` durumlarını ayrı tutar.

## Emir Öncesi
- Idempotency key/order_id doğrula.
- Broker, market, side, qty, price, stop ve target doğrula.
- Bid/ask ve spread taze olmalı.
- Emir türü ve timeframe piyasaya uygun olmalı.
- Aynı sinyal için tek route çalışmalı.

## Emir Sonrası
- Broker response ve fill doğrulanmadan local pozisyonu `OPEN` yapma.
- Partial fill için gerçek quantity kullan.
- Stop/TP emirlerinin broker’da gerçekten açık olduğunu kontrol et.
- Slippage, latency, reject reason ve fill timestamp kaydet.
- Retry yalnızca idempotent ve limitli olsun; duplicate order üretmesin.

## Mutabakat
Local state ile broker state her döngüde karşılaştırılır. Fark varsa yeni işlem durur, otomatik resume varsayılan olarak kapalı kalır. Broker erişilemezliği simulation başarı gibi raporlanmaz.

## Çıktı
`order_id`, `execution_state`, `broker_status`, `fill_qty`, `avg_fill_price`, `slippage_bps`, `latency_ms`, `bracket_status`, `reconciliation_status` ve `failure_reason` alanlarını döndür. Secret veya tam credential loglama.
