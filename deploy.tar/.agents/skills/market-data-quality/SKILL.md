---
name: market-data-quality
description: "Use when validating live market data, freshness, liquidity, spread, volume, missing indicators, source conflicts, or deciding whether stale data must produce NO-TRADE."
---

# Market Data Quality

Bu skill karar üretmeden önce verinin gerçekten kullanılabilir olup olmadığını denetler. Veri eksikliği nötr kabul edilmez; kritik alan eksikse işlem ertelenir.

## Zorunlu Kontroller
- Sembol, piyasa, timeframe ve kaynak mevcut mu?
- Son güncelleme yaşı limit içinde mi?
- Fiyat, bid, ask, hacim ve ATR pozitif mi?
- Hacim oranı teyitli mi, yoksa varsayılan değer mi?
- TradingView ve broker fiyatı arasında kabul edilemez fark var mı?
- Spread ölçümü gerçek quote üzerinden mi?
- Makro/haber verisi mevcut mu, yoksa fallback mi?
- İndikatörlerin zaman damgaları aynı veri kesitine mi ait?

## Fail-Closed Kuralları
- Quote yoksa `NO-TRADE` veya `WAIT`.
- Stale veri varsa yeni giriş yok.
- Bid/ask yoksa spread onayı yok.
- Hacim null/varsayılan ise volume confirmation yok.
- Kaynaklar çatışıyorsa düşük güven ve işlem erteleme.
- Fallback veri hiçbir zaman `REAL` etiketiyle gösterilmez.

## Çıktı
`data_quality`, `source`, `age_seconds`, `missing_fields`, `conflicts`, `liquidity_status` ve `decision_gate` alanlarını döndür. Gizli değer veya API anahtarı gösterme.
