---
name: walk-forward-validation
description: "Use when backtesting, comparing strategies, calibrating ML signals, measuring performance, detecting overfitting, or approving a strategy for PAPER testing."
---

# Walk-Forward Validation

Backtest sonucu canlı kazanç garantisi değildir. Strateji önce train, validation, test ve forward dönemlerinde ayrı değerlendirilir.

## Veri Kuralları
- Look-ahead ve leakage kontrolü.
- Zaman sıralı train/validation/test ayrımı.
- Survivorship bias ve delisted asset etkisi.
- Fee, spread, slippage, latency ve partial fill simülasyonu.
- Her piyasa ve rejim için ayrı metrik.

## Değerlendirme
- Net PnL, profit factor, expectancy, Sharpe/Sortino.
- Max drawdown, recovery factor, turnover.
- Win rate tek başına başarı değildir.
- Out-of-sample sonuç in-sample sonucundan kopuk raporlanır.
- Minimum trade sample ve güven aralığı belirtilir.
- Parametre değişikliği önce PAPER shadow testine gider.

## Onay Kapıları
1. Veri kalite raporu geçmeli.
2. OOS performans pozitif ve maliyet sonrası anlamlı olmalı.
3. Drawdown ve günlük zarar limiti kabul edilebilir olmalı.
4. Farklı rejimlerde kırılganlık raporlanmalı.
5. PAPER forward test tamamlanmadan LIVE önerilmez.

## Çıktı
`dataset_period`, `train_period`, `validation_period`, `test_period`, `oos_metrics`, `cost_model`, `drawdown`, `overfit_flags`, `sample_size`, `confidence_interval`, `paper_gate` ve `recommendation` döndür.
