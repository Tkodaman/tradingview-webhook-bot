﻿---
name: Veri ve Analiz Ajani (Data & Analysis Agent)
description: Canli piyasa verisi ceker, 24 kantitatif indikator uzerinden degerlendirme yapar ve deterministik BUY/SELL/HOLD/BLOCK sinyali + TP/SL onerisi uretir. LLM bagimliligi yoktur.
author: System
version: "1.0"
---

# Veri & Analiz Ajanı (Data & Analysis Agent)

## Görev Tanımı
Bu ajan tek bir sorumluluktur: **canlı piyasa verisini analiz et → net öneri üret.**

## Mimari

`
TradingView Scanner (3s TTL cache)
          ↓
DataAnalysisAgent._evaluate_single(symbol, raw_data)
          ↓
 ┌─ TV verilerini doğrudan kullan (fiyat, RSI, MACD, ADX, Stoch, VWAP, hacim)
 ├─ TV'den gelmeyen değerleri istatistiksel tahmin ile üret (Hurst, Z-Score vb.)
 └─ Quantitative24Engine ile 24 indikatör değerlendir
          ↓
 Signal + Confidence + TP + SL + R:R + Uyarılar
`

## Sinyal Eşikleri

| Skor  | Geçen | Sinyal      | Güven    |
|-------|-------|-------------|----------|
| ≥82   | ≥20   | STRONG_BUY  | >85%     |
| ≥65   | ≥15   | BUY         | 65-85%   |
| ≥45   | ≥10   | HOLD        | 45-65%   |
| <45   | <10   | BLOCK       | <45%     |

## TP/SL Formülü (ATR bazlı)
- TP = entry × (1 + ATR% × 1.5)
- SL = entry × (1 - ATR% × 0.75)
- Risk/Reward = TP_pct / SL_pct (her zaman ≥ 2.0:1)

## REST Endpoints

| Endpoint                          | Açıklama                                   |
|-----------------------------------|--------------------------------------------|
| GET /api/analysis/health          | Ajan durum kontrolü                        |
| GET /api/analysis/scan            | Tüm evren taraması, skora göre sıralı      |
| GET /api/analysis/top-picks       | Yalnızca BUY/STRONG_BUY sinyalli varlıklar |
| GET /api/analysis/symbol/{SYMBOL} | Tek sembol anlık analizi                   |

## Kullanım Örnekleri

`python
# Tek sembol analizi
from services.agents.data_analysis_agent import data_analysis_agent
result = data_analysis_agent.analyze_symbol("BTCUSDT")

# Tüm evren taraması
all_results = data_analysis_agent.analyze_all()

# Sadece alınabilir fırsatlar
picks = data_analysis_agent.top_picks()
`

## Tasarım Kuralları
1. **LLM yok** — her karar deterministik ve açıklanabilir
2. **Tek sorumluluk** — sadece veri + analiz, işlem kararı vermez
3. **Hata toleransı** — bir sembol çökerse diğerleri devam eder
4. **Cache** — 5 s TTL, gereksiz TV istek yükü olmadan
5. **Sıfır yan etki** — mevcut hiçbir servisi değiştirmez
