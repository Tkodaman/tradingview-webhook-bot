import os
import json
import shutil
import time

history_dir = os.path.expandvars(r"%APPDATA%\Code\User\History")
workspace_prefix = "file:///c%3A/Users/ASUS/OneDrive/Desktop/tradingview-webhook-bot"

recovered_dir = "recovered_files"
os.makedirs(recovered_dir, exist_ok=True)

found_files = []

for folder in os.listdir(history_dir):
    folder_path = os.path.join(history_dir, folder)
    if not os.path.isdir(folder_path): continue
    
    entries_file = os.path.join(folder_path, "entries.json")
    if not os.path.exists(entries_file): continue
    
    try:
        with open(entries_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
    except Exception:
        continue
        
    resource = data.get("resource", "")
    # Check lowercase to match case-insensitively
    if resource.lower().startswith(workspace_prefix.lower()):
        entries = data.get("entries", [])
        if not entries: continue
        
        # Sort by timestamp descending
        entries.sort(key=lambda x: x.get("timestamp", 0), reverse=True)
        
        latest_entry = entries[0]
        file_id = latest_entry["id"]
        source_path = os.path.join(folder_path, file_id)
        
        if os.path.exists(source_path):
            rel_path = resource.replace(workspace_prefix, "").replace(workspace_prefix.lower(), "").lstrip("/")
            rel_path = rel_path.replace("%5C", "/").replace("%20", " ") # decode some URL chars
            
            dest_path = os.path.join(recovered_dir, rel_path.replace("/", "_"))
            shutil.copy2(source_path, dest_path)
            
            ts = latest_entry.get("timestamp", 0)
            time_str = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(ts/1000))
            found_files.append({"original": rel_path, "recovered": dest_path, "time": time_str, "size": os.path.getsize(source_path)})

with open("recovery_log.json", "w", encoding="utf-8") as f:
    json.dump(found_files, f, indent=4)

print(f"Recovered {len(found_files)} files.")
