with open('templates/dashboard.html', 'r', encoding='utf-8') as f:
    lines = f.readlines()

for i in range(len(lines)-1, -1, -1):
    if '</div>' in lines[i]:
        print('Last div at line:', i+1)
        print(lines[i])
        break
