import codecs

# Read the UTF-16 old file
try:
    with codecs.open('dashboard_old.html', 'r', 'utf-16') as f:
        content = f.read()
except Exception as e:
    print('Failed to read old file as utf-16:', e)
    with open('dashboard_old.html', 'r', encoding='utf-8', errors='ignore') as f:
        content = f.read()

# Fix the broken javascript boundary if it exists
if '});\r\n\r\n        // ================================================================\r\n        // ?? MAKRO HABER FEED' in content:
    print('Found the broken boundary. Fixing...')
    content = content.replace('});\r\n\r\n        // ================================================================\r\n        // ?? MAKRO HABER FEED',
                              '});\r\n        }\r\n        </script>\r\n        <script>\r\n        // ================================================================\r\n        // ?? MAKRO HABER FEED')
else:
    # try a more generic replace
    content = content.replace('});\n\n        // ================================================================\n        // ?? MAKRO HABER FEED',
                              '});\n        }\n        </script>\n        <script>\n        // ================================================================\n        // ?? MAKRO HABER FEED')

# Make sure there is a closing script and body tags if they are missing
if '</body>' not in content:
    content += '\n</script>\n</body>\n</html>'

# Write to templates/dashboard.html in UTF-8
with open('templates/dashboard.html', 'w', encoding='utf-8') as f:
    f.write(content)
    
print('Repaired dashboard_old.html and wrote to templates/dashboard.html')
