import re
with open('templates/dashboard.html', 'r', encoding='utf-8') as f:
    lines = f.readlines()

for i in range(5800, -1, -1):
    if '</div>' in lines[i]:
        print('Last div before 5800 at line:', i+1)
        print(''.join(lines[i-10:i+10]))
        break
