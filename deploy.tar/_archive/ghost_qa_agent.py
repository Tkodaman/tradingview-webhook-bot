"""
GHOST QA AGENT - Gizli Musteri Uctan Uca Sistem Dogrulama Ajani
Botun tum kritik akislarini disaridan HTTP uzerinden test eder.
PAPER ortami - gercek para riski yok.
"""
import sys, io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')

import sys
import time
import json
import requests
from typing import Any, Dict, Optional, Tuple
from datetime import datetime

# ─── Konfig ───────────────────────────────────────────────────────────────────
BASE_URL    = "http://127.0.0.1:8000"
PASSPHRASE  = "secret_key"
TEST_SYMBOL = "XRPUSD"   # Alpaca kripto formatı (slash yok)
TEST_CAP    = 20.0        # $20 sembolik test sermayesi
TIMEOUT     = 25          # saniye — Alpaca canlı çağrıları için yeterli süre

# ─── Renk Kodları (ANSI) ──────────────────────────────────────────────────────
G  = "\033[92m"   # Yeşil — PASS
R  = "\033[91m"   # Kırmızı — FAIL
Y  = "\033[93m"   # Sarı — WARN
B  = "\033[94m"   # Mavi — bilgi
C  = "\033[96m"   # Cyan — başlık
W  = "\033[97m"   # Beyaz
DIM= "\033[2m"    # Soluk
RST= "\033[0m"    # Sıfırla

# ─── Sonuç Takip Değişkenleri ─────────────────────────────────────────────────
results: list = []
opened_pos_id: Optional[str] = None
opened_pos_symbol: Optional[str] = None

# ══════════════════════════════════════════════════════════════════════════════
# Yardımcı Fonksiyonlar
# ══════════════════════════════════════════════════════════════════════════════

def banner():
    ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    print(f"""
{C}========================================================================
   GHOST QA AGENT  -- Gizli Musteri Sistem Testi
   Tarih: {ts}  |  Hedef: {BASE_URL}
========================================================================{RST}
""")

def section(title: str):
    print(f"\n{C}" + "-"*70)
    print(f"  {title}")
    print("-"*70 + RST)

def log_result(num: int, name: str, passed: bool, warn: bool,
               ms: float, detail: str, extra: str = ""):
    icon = f"{G}[PASS]{RST}" if passed else (f"{Y}[WARN]{RST}" if warn else f"{R}[FAIL]{RST}")
    speed_color = G if ms < 300 else (Y if ms < 1000 else R)
    speed = f"{speed_color}{ms:.0f}ms{RST}"
    print(f"  [{num:02d}] {icon}  {W}{name}{RST}  {DIM}({speed}){RST}")
    if detail:
        print(f"       {DIM}>> {detail}{RST}")
    if extra:
        print(f"       {B}>> {extra}{RST}")
    results.append({
        "num": num, "name": name,
        "passed": passed, "warn": warn, "ms": ms, "detail": detail
    })

def req(method: str, path: str, body: dict = None,
        expected_key: str = None, retries: int = 1) -> Tuple[bool, bool, float, dict, str]:
    """HTTP isteği atar. Timeout'da 1 kez tekrar dener. (passed, warn, ms, data, detail) döner."""
    url = f"{BASE_URL}{path}"
    for attempt in range(retries + 1):
        t0 = time.time()
        try:
            if method == "GET":
                r = requests.get(url, timeout=TIMEOUT)
            else:
                r = requests.post(url, json=body, timeout=TIMEOUT)
            ms = (time.time() - t0) * 1000

            if r.status_code >= 500:
                return False, False, ms, {}, f"HTTP {r.status_code}: {r.text[:120]}"
            if r.status_code == 404:
                return False, False, ms, {}, f"HTTP 404 — Endpoint bulunamadı: {path}"

            try:
                data = r.json()
            except Exception:
                data = {}

            warn = ms > 1000
            if expected_key and expected_key not in data:
                return False, False, ms, data, f"Beklenen alan '{expected_key}' yanıtta yok. Gelen: {list(data.keys())[:6]}"

            return True, warn, ms, data, ""
        except requests.exceptions.ConnectionError:
            ms = (time.time() - t0) * 1000
            return False, False, ms, {}, f"BAĞLANTI HATASI — Bot çalışıyor mu? ({BASE_URL})"
        except requests.exceptions.Timeout:
            ms = (time.time() - t0) * 1000
            if attempt < retries:
                print(f"       {Y}>> Timeout, 3s bekleyip tekrar deneniyor... (deneme {attempt+2}/{retries+1}){RST}")
                time.sleep(3)
                continue
            return False, False, ms, {}, f"ZAMAN AŞIMI ({TIMEOUT}s) — {retries+1} denemede de yanıt alınamadı"
        except Exception as e:
            ms = (time.time() - t0) * 1000
            return False, False, ms, {}, str(e)
    return False, False, 0, {}, "Bilinmeyen hata"


# ══════════════════════════════════════════════════════════════════════════════
# GRUP 1 — Sağlık & Bağlantı
# ══════════════════════════════════════════════════════════════════════════════

def test_group_1():
    section("🔴 GRUP 1 — Bot Sağlığı & Temel Bağlantı")

    # T-01: Health check
    ok, w, ms, data, err = req("GET", "/health", expected_key="status")
    detail = f"trading_mode={data.get('trading_mode')}, max_risk={data.get('max_risk_allowed')}" if ok else err
    log_result(1, "Bot Sağlık Kontrolü (/health)", ok, w, ms, detail)

    # T-02: Canlı piyasa feed'i
    ok, w, ms, data, err = req("GET", "/api/market/live-feed")
    if ok:
        tick_count = len(data.get("market_ticks", {}))
        balance = data.get("account_balance", 0)
        detail = f"{tick_count} sembol izleniyor | Hesap: ${balance:.2f}"
        passed = tick_count > 0
        if not passed:
            err = "market_ticks boş — TradingView bağlantısı yok olabilir"
    else:
        passed = False
        detail = err
    log_result(2, "Canlı Piyasa Feed (WebSocket/TV)", passed or ok, w, ms, detail if passed else err)

    # T-03: Alpaca pozisyon senkronizasyonu
    ok, w, ms, data, err = req("GET", "/api/positions/active")
    if ok:
        positions = data.get("active_positions", [])
        balance = data.get("account_balance", 0)
        detail = f"Açık pozisyon: {len(positions)} | Alpaca bakiyesi: ${balance:.2f}"
        passed = True
    else:
        passed = False
        detail = err
    log_result(3, "Alpaca Pozisyon Senkronizasyonu", passed, w, ms, detail)


# ══════════════════════════════════════════════════════════════════════════════
# GRUP 2 — Analitik Motor Testleri
# ══════════════════════════════════════════════════════════════════════════════

def test_group_2():
    section("🟡 GRUP 2 — Analitik Motor & Karar Algoritması")

    # T-04: Sinyal matrisi (WAIT / BUY / SELL kararları)
    ok, w, ms, data, err = req("GET", "/api/market/live-matrix")
    if ok:
        matrix = data.get("matrix", [])
        summary = data.get("signals_summary", {})
        buy_c  = summary.get("BUY", 0)
        sell_c = summary.get("SELL", 0)
        wait_c = summary.get("WAIT", 0)
        hold_c = summary.get("HOLD", 0)
        detail = f"{len(matrix)} varlık tarandı → BUY:{buy_c}  SELL:{sell_c}  WAIT:{wait_c}  HOLD:{hold_c}"
        passed = len(matrix) > 0
    else:
        passed = False
        detail = err
    log_result(4, "Sinyal Matrisi (BUY/SELL/WAIT Kararı)", passed, w, ms, detail)

    # T-05: Risk kapısı — XRPUSD için $20 pozisyon
    gate_body = {
        "symbol": TEST_SYMBOL,
        "market": "CRYPTO",
        "requested_size_usd": TEST_CAP,
        "signal_score": 80.0
    }
    ok, w, ms, data, err = req("POST", "/api/risk/gate", body=gate_body)
    if ok:
        allowed = data.get("allowed", False)
        reason  = data.get("reason", "—")
        rules   = data.get("triggered_rules", [])
        detail  = f"Karar: {'AÇILSIN ✅' if allowed else 'ENGEL 🚫'}  |  Gerekçe: {reason}"
        extra   = f"Geçilen kurallar: {rules[:3]}" if rules else ""
        passed  = True  # API'nin cevap vermesi yeterli, karar ortama göre değişebilir
    else:
        passed = False
        detail = err
        extra = ""
    log_result(5, "Risk Kapısı — Trade Gate (7 Kural Denetimi)", passed, w, ms, detail, extra)

    # T-06: TP/SL seviye hesaplama (ATR bazlı, R:R ≥ 1.8:1)
    levels_body = {
        "entry_price": 1.42,   # Anlık XRP fiyatına yakın
        "atr_pct": 1.8,
        "signal": "BUY",
        "market": "CRYPTO"
    }
    ok, w, ms, data, err = req("POST", "/api/risk/levels", body=levels_body)
    if ok:
        tp    = data.get("tp_price", 0)       # API: tp_price
        sl    = data.get("sl_price", 0)       # API: sl_price
        be    = data.get("be_trigger_price", 0)
        rr_raw= data.get("risk_reward", "0")  # API: string ornegin "4.29:1"
        try:
            rr = float(str(rr_raw).split(":")[0]) if ":" in str(rr_raw) else float(rr_raw)
        except Exception:
            rr = 0.0
        tp_pct = data.get("tp_pct", 0)
        sl_pct = data.get("sl_pct", 0)
        detail = f"TP: ${tp:.4f} (+{tp_pct:.2f}%)  |  SL: ${sl:.4f} (-{sl_pct:.2f}%)  |  BE: ${be:.4f}  |  R:R = {rr:.2f}"
        passed = tp > 0 and sl > 0 and rr >= 1.0
        if rr < 1.8:
            detail += f"  -- R:R < 1.8 (hedef: >=1.8, simdiki: {rr:.2f})"
    else:
        passed = False
        detail = err
    log_result(6, "TP/SL/BE Seviye Hesaplama (ATR Bazlı, R:R Testi)", passed, w, ms, detail)

    # T-07: Portföy sağlığı ve drawdown limiti
    ok, w, ms, data, err = req("GET", "/api/risk/health")
    if ok:
        score   = data.get("health_score", 0)
        status  = data.get("status", "?")
        equity  = data.get("equity", 0)
        dd      = data.get("drawdown_pct", 0)
        daily   = data.get("daily_pnl", 0)
        alerts  = data.get("alerts", [])
        mode    = data.get("risk_mode", "?")
        detail  = f"Sağlık: {score}/100 ({status})  |  Equity: ${equity:.2f}  |  Drawdown: %{dd:.2f}  |  Günlük PnL: ${daily:.2f}  |  Mod: {mode}"
        extra   = f"Uyarılar: {alerts}" if alerts else "Aktif uyarı yok ✅"
        passed  = score is not None
    else:
        passed = False
        detail = err
        extra  = ""
    log_result(7, "Portföy Sağlığı & Drawdown Limiti", passed, w, ms, detail, extra)

    # T-08: Otonom motor çalışma durumu
    ok, w, ms, data, err = req("GET", "/api/auto-runner/status")
    if ok:
        running = data.get("is_running", False)
        interval = data.get("scan_interval_seconds", "?")
        risk_mode = data.get("current_risk_mode", "?")
        detail = f"Motor: {'ÇALIŞIYOR 🟢' if running else 'DURDU 🔴'}  |  Tarama aralığı: {interval}s  |  Risk modu: {risk_mode}"
        passed = running
    else:
        passed = False
        detail = err
    log_result(8, "Otonom Tarayıcı Motor Durumu (7/24)", passed, w, ms, detail)


# ══════════════════════════════════════════════════════════════════════════════
# GRUP 3 — Pozisyon Yaşam Döngüsü (En Kritik)
# ══════════════════════════════════════════════════════════════════════════════

def test_group_3():
    global opened_pos_id, opened_pos_symbol
    section("🟠 GRUP 3 — Pozisyon Yaşam Döngüsü (AÇIŞ → SL/TP → KAPATMA)")

    # T-09: Pozisyon AÇMA
    print(f"\n  {Y}>> Test pozisyonu aciliyor: {TEST_SYMBOL} | ${TEST_CAP} | PAPER{RST}")
    open_body = {
        "symbol": TEST_SYMBOL,
        "capital": TEST_CAP,
        "side": "BUY",
        "tp_pct": 3.0,
        "sl_pct": 1.5
    }
    ok, w, ms, data, err = req("POST", "/api/positions/open", body=open_body)
    if ok:
        # API iki farkli format donebilir:
        # 1) {"status":"success", "pos_id":"..."}  -> broker aktif
        # 2) ActivePosition objesi direkt -> fallback (local)
        status_val = data.get("status", "")
        pos_id_val = data.get("pos_id", "") or data.get("id", "")

        # ActivePosition direkt donmesse status alani yok ama 'id' var
        if not status_val and data.get("id"):
            status_val = "OPEN"   # fallback modu — lokal pozisyon acildi
            pos_id_val = data.get("id", "")

        passed = status_val in ("success", "OPEN") and pos_id_val != ""
        detail = f"status={status_val} | pos_id={pos_id_val or 'N/A'} | {data.get('message','')}"
        if passed and pos_id_val:
            opened_pos_id     = pos_id_val
            opened_pos_symbol = TEST_SYMBOL
    else:
        passed = False
        detail = err
    log_result(9, f"Pozisyon AÇMA — {TEST_SYMBOL} ${TEST_CAP} (PAPER)", passed, w, ms, detail)

    time.sleep(3)  # Alpaca fill + cache sifirlanmasi icin bekleme

    # T-10: Pozisyon panelde görünüyor mu? (SL/TP seviyeleri var mı?)
    ok, w, ms, data, err = req("GET", "/api/positions/active")
    if ok:
        positions = data.get("active_positions", [])
        xrp_pos   = next((p for p in positions if TEST_SYMBOL.replace("/","") in p.get("symbol","").replace("/","")), None)
        if xrp_pos:
            tp_p  = xrp_pos.get("target_profit_price", 0)
            sl_p  = xrp_pos.get("stop_loss_price", 0)
            entry = xrp_pos.get("entry_price", 0)
            curr  = xrp_pos.get("current_price", 0)
            pnl   = xrp_pos.get("unrealized_pnl", 0)
            pnl_p = xrp_pos.get("unrealized_pnl_pct", 0)
            detail = (f"Giris: ${entry:.4f}  |  Su an: ${curr:.4f}  |  "
                      f"TP: ${tp_p:.4f}  |  SL: ${sl_p:.4f}  |  "
                      f"PnL: ${pnl:.2f} (%{pnl_p:.2f})")
            passed = tp_p > 0 and sl_p > 0
            if not opened_pos_id and xrp_pos.get("id"):
                opened_pos_id = xrp_pos.get("id")
            extra = f"Makas: TP farki %{((tp_p-entry)/entry*100):.2f}  |  SL farki %{((entry-sl_p)/entry*100):.2f}" if entry > 0 else ""
        else:
            passed = False
            detail = f"{TEST_SYMBOL} panelde gorunmuyor! Alpaca-yerel senkronizasyon bozuk."
            extra  = f"Paneldeki pozisyonlar: {[p.get('symbol') for p in positions]}"
    else:
        # Timeout veya hata — sunucunun toparlanmasi icin bekle
        time.sleep(3)
        passed = False
        detail = err
        extra  = ""
    log_result(10, "Pozisyon Panelde Görünüyor & SL/TP Seviyeleri Doğru", passed, w, ms, detail, extra)

    # T-11: MAKAS (Spread) analizi — TP-SL asimetrisi
    ok2, w2, ms2, data2, err2 = req("POST", "/api/risk/levels", body={
        "entry_price": 1.42, "atr_pct": 1.8, "signal": "BUY", "market": "CRYPTO"
    })
    if ok2:
        tp_p2  = data2.get("tp_price", 0)
        sl_p2  = data2.get("sl_price", 0)
        rr_raw2 = data2.get("risk_reward", "0")
        try:
            rr2 = float(str(rr_raw2).split(":")[0]) if ":" in str(rr_raw2) else float(rr_raw2)
        except Exception:
            rr2 = 0.0
        tp_pct2 = data2.get("tp_pct", 0)
        sl_pct2 = data2.get("sl_pct", 0)
        asym  = round(tp_pct2 / sl_pct2, 2) if sl_pct2 > 0 else 0
        detail2 = (f"TP makas: %{tp_pct2:.2f}  |  SL makas: %{sl_pct2:.2f}  |  "
                   f"Asimetri (TP/SL orani): {asym}x  |  R:R = {rr2:.2f}")
        passed2 = asym >= 1.5
        extra2  = "Asimetrik makas uygun" if passed2 else "Makas dar -- R:R iyilestirilmeli"
    else:
        passed2 = False
        detail2 = err2
        extra2  = ""
    log_result(11, "MAKAS (Spread) Asimetri Testi — TP/SL Oranı", passed2, w2, ms2, detail2, extra2)

    # T-12: WAIT sinyali — parity zayıfken giriş engeli çalışıyor mu?
    # Düşük skor ile risk gate'i test et
    gate_low = {
        "symbol": "DOTUSDT",
        "market": "CRYPTO",
        "requested_size_usd": 500.0,  # Kasadan fazla talep — engellenmeli
        "signal_score": 20.0          # Çok düşük skor
    }
    ok3, w3, ms3, data3, err3 = req("POST", "/api/risk/gate", body=gate_low)
    if ok3:
        allowed3 = data3.get("allowed", True)
        reason3  = data3.get("reason", "?")
        detail3  = f"Düşük skorlu aşırı büyük pozisyon: {'ENGELLENDI 🚫' if not allowed3 else '⚠️ GEÇTİ (beklenmiyordu)'}  |  {reason3}"
        passed3  = not allowed3  # Engellenmesi BEKLENEN sonuç
    else:
        passed3 = False
        detail3 = err3
    log_result(12, "WAIT Sinyali — Aşırı Büyük/Düşük Skorlu Pozisyon ENGELİ", passed3, w3, ms3, detail3)

    # T-13: Webhook sinyal alımı
    webhook_body = {
        "passphrase": PASSPHRASE,
        "action": "BUY",
        "symbol": "ETHUSD",
        "price": 2484.0,
        "quantity": 0.005,
        "take_profit": 2560.0,
        "stop_loss": 2440.0,
        "account_equity": 100.0,
        "market_position": "long",
        "indicators": {"rsi": 55.0, "volume_ratio": 1.3},
        "macro_tags": ["TEST_WEBHOOK"]
    }
    ok4, w4, ms4, data4, err4 = req("POST", "/webhook", body=webhook_body)
    if ok4:
        status4 = data4.get("status", "?")
        reason4 = data4.get("reason", data4.get("message", ""))
        detail4 = f"Webhook yaniti: status={status4}  |  {reason4}"
        passed4 = status4 in ("success", "rejected", "blocked", "REJECTED", "BLOCKED")
    else:
        passed4 = False
        detail4 = err4
    log_result(13, "Webhook Sinyal Alımı & Execution Agent Tetiklemesi", passed4, w4, ms4, detail4)

    # T-14: Pozisyon KAPATMA (açtığımız test pozisyonunu kapat)
    time.sleep(1)
    if opened_pos_id:
        # Tam pos_id ile dene
        close_path = f"/api/positions/close/{opened_pos_id}"
        print(f"\n  {Y}>> Test pozisyonu kapatiliyor: {opened_pos_id}{RST}")
        ok5, w5, ms5, data5, err5 = req("POST", close_path)
        if not ok5 or data5.get("status") != "success":
            # Fallback: sembol ile dene
            ok5, w5, ms5, data5, err5 = req("POST", f"/api/positions/close/{TEST_SYMBOL}")
        if ok5:
            status5 = data5.get("status", "?")
            closed  = data5.get("closed_position", {})
            pnl5    = closed.get("net_pnl", closed.get("unrealized_pnl", "?"))
            reason5 = closed.get("reason", "MANUAL_CLOSE")
            detail5 = f"Kapanma: status={status5} | PnL=${pnl5} | Neden={reason5}"
            passed5 = status5 == "success"
        else:
            passed5 = False
            detail5 = err5
        w5 = False
    else:
        # pos_id bulunamadıysa, sembol üzerinden dene
        print(f"\n  {Y}>> pos_id bulunamadi, sembol uzerinden kapama deneniyor: {TEST_SYMBOL}{RST}")
        ok5, w5, ms5, data5, err5 = req("POST", f"/api/positions/close/{TEST_SYMBOL}")
        if ok5:
            status5 = data5.get("status", "?")
            passed5 = status5 == "success"
            detail5 = f"status={status5}"
        else:
            passed5 = False
            ms5 = 0
            detail5 = "⚠️ Pozisyon ID bulunamadı — test pozisyonu açılamamış olabilir. Alpaca panelini kontrol edin."
    log_result(14, f"Pozisyon KAPATMA & Alpaca Senkronizasyonu ({TEST_SYMBOL})", passed5, w5 if opened_pos_id else False, ms5, detail5)


# ══════════════════════════════════════════════════════════════════════════════
# ÖZET RAPOR
# ══════════════════════════════════════════════════════════════════════════════

def print_summary():
    section("GHOST QA AGENT -- OZET RAPOR")
    total   = len(results)
    passed  = sum(1 for r in results if r["passed"])
    warned  = sum(1 for r in results if r["warn"] and r["passed"])
    failed  = total - passed
    score_c = G if failed == 0 else (Y if failed <= 2 else R)

    print(f"\n  {score_c}" + "="*60 + RST)
    print(f"  {score_c}  TOPLAM SKOR: {passed}/{total} TEST GECILDI{RST}")
    if warned > 0:
        print(f"  {Y}  {warned} test yavas yanit uyarisi aldi (>1000ms){RST}")
    print(f"  {score_c}" + "="*60 + RST + "\n")

    if failed > 0:
        print(f"  {R}BASARISIZ TESTLER:{RST}")
        for r in results:
            if not r["passed"]:
                print(f"   {R}[{r['num']:02d}] {r['name']}{RST}")
                print(f"        {DIM}>> {r['detail']}{RST}")
        print()

    print(f"  {DIM}Tum testler tamamlandi.{RST}")
    if failed == 0:
        print(f"\n  {G}Bot %%100 saglikli -- tum sistemler stabil ve akici!{RST}\n")
    elif failed <= 2:
        print(f"\n  {Y}Bot buyuk olcude calisiyor ancak {failed} konu dikkat gerektiriyor.{RST}\n")
    else:
        print(f"\n  {R}Kritik sorunlar tespit edildi! {failed} test basarisiz. Inceleme gerekiyor.{RST}\n")

    return failed == 0


# ══════════════════════════════════════════════════════════════════════════════
# ANA AKIŞ
# ══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    banner()
    print(f"  {DIM}Bot adresi  : {BASE_URL}")
    print(f"  Test varligi: {TEST_SYMBOL}  |  Sermaye: ${TEST_CAP}  |  Ortam: PAPER{RST}\n")

    try:
        test_group_1()
        test_group_2()
        test_group_3()
        ok = print_summary()
        sys.exit(0 if ok else 1)
    except KeyboardInterrupt:
        print(f"\n{Y}⚡ Test kullanıcı tarafından durduruldu.{RST}\n")
        sys.exit(2)
