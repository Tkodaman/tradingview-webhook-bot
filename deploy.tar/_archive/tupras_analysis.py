import json
from services.agents.data_analysis_agent import data_analysis_agent

result = data_analysis_agent.analyze_symbol('TUPRS')
print(json.dumps(result, indent=2))
