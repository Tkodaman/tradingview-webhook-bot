function renderTop5Momentum(uiData) {
try {
if (!uiData || uiData.status !== "success") return;

let activeSymbols = [];
let activePositionsData = uiData.active_positions || [];
activeSymbols = activePositionsData.map(p => p.symbol);

if (!window.prevPositionsData) window.prevPositionsData = {};
let currentPositionsData = {};
activePositionsData.forEach(p => {
let s = p.symbol.replace(/[^A-Za-z0-9]/g, '').toUpperCase();
currentPositionsData[s] = p;
});

if (window.prevActiveSymbols) {
activeSymbols.forEach(sym => {
if (!window.prevActiveSymbols.includes(sym)) {
let sStr = sym.replace(/[^A-Za-z0-9]/g, '').toUpperCase();
window.assetEvents[sStr] = { type: 'BUY', time: Date.now(), msg: 'Varlık Alındı 🚀', color: '#4ade80' };
}
});
window.prevActiveSymbols.forEach(sym => {
if (!activeSymbols.includes(sym)) {
let sStr = sym.replace(/[^A-Za-z0-9]/g, '').toUpperCase();
let oldPos = window.prevPositionsData[sStr];
if (oldPos) {
let pnl = parseFloat(oldPos.pnl_pct || oldPos.unrealized_pnl || 0);
let isProfit = pnl >= 0;
let msg = isProfit ? 'Kârlı Satış Yapıldı 💰' : 'Zararla Satıldı 🛑';
let color = isProfit ? '#4ade80' : '#f87171';
window.assetEvents[sStr] = { type: 'SELL', time: Date.now(), msg: msg, color: color };
}
}
});
}
window.prevActiveSymbols = activeSymbols;
window.prevPositionsData = currentPositionsData;

// Advisory Streams
if (uiData.advisory_streams) {
const updateMarquee = (id, streamArr) => {
if (!streamArr || streamArr.length === 0) return;
const el = document.getElementById(id);
if (el) {
const newText = streamArr.join(' &nbsp; | &nbsp; ');
const rawText = streamArr.join(' | '); 
if (el.getAttribute('data-raw') !== rawText) {
el.setAttribute('data-raw', rawText);
el.innerHTML = newText;

// Flash efekti uygula (parent üzerinde daha iyi durur veya marquee'nin kendisinde)
el.classList.remove('flash-update');
void el.offsetWidth; // trigger reflow
el.classList.add('flash-update');
}
}
};
updateMarquee('cryptoAdvisoryMarquee', uiData.advisory_streams['CRYPTO']);
updateMarquee('nasdaqAdvisoryMarquee', uiData.advisory_streams['NASDAQ']);
updateMarquee('bistAdvisoryMarquee', uiData.advisory_streams['BIST']);
}

// Top Actionable Picks
const data = { top5: uiData.top_picks || [] };

const cBody = document.getElementById('top10CryptoBody');
const nBody = document.getElementById('top10NasdaqBody');
const bBody = document.getElementById('top10BistBody');
if (!cBody || !nBody || !bBody) return;

cBody.innerHTML = ''; 
nBody.innerHTML = ''; 
bBody.innerHTML = '';

if (data.top5.length === 0) {
cBody.innerHTML = '<div style="font-size:10px;text-align:center;grid-column: span 2;">Veri yok</div>';
return;
}

const sortLogic = (a, b) => {
let aStr = (a.symbol||'').replace(/[^A-Za-z0-9]/g, '').toUpperCase();
let bStr = (b.symbol||'').replace(/[^A-Za-z0-9]/g, '').toUpperCase();

let aBought = activeSymbols.some(s => {
let ac = s.replace(/[^A-Za-z0-9]/g, '').toUpperCase();
return ac === aStr || ac === aStr + 'T' || aStr === ac + 'T';
});
let bBought = activeSymbols.some(s => {
let bc = s.replace(/[^A-Za-z0-9]/g, '').toUpperCase();
return bc === bStr || bc === bStr + 'T' || bStr === bc + 'T';
});
if (aBought && !bBought) return -1;
if (!aBought && bBought) return 1;

let aConf = parseFloat(a.confidence_pct || 0);
let bConf = parseFloat(b.confidence_pct || 0);
return bConf - aConf;
};
const cryptoItems = data.top5.filter(t => t.market === 'CRYPTO').sort(sortLogic).slice(0, 15);
const nasdaqItems = data.top5.filter(t => t.market === 'NASDAQ').sort(sortLogic).slice(0, 15);
const bistItems = data.top5.filter(t => t.market === 'BIST').sort(sortLogic).slice(0, 15);

const renderRow = (t, bodyEl) => {
const sym = t.symbol || 'UNKNOWN';

const rsiVal = t.rsi !== undefined ? t.rsi : 50;
const volVal = t.volume_ratio !== undefined ? t.volume_ratio : 1.0;
let confNum = parseFloat(t.confidence_pct || 0);
let isWhaleOverride = false;
let reason = (t.key_alerts && t.key_alerts.length > 0) ? t.key_alerts[0] : (confNum > 85 ? 'Aşırı Momentum' : 'Trend Teyidi');

// CÜRETKAR ATAK (WHALE OVERRIDE) PROTOKOLÜ
if (rsiVal >= 70 && volVal >= 2.5) {
isWhaleOverride = true;
confNum = 99.9; // Otonom Korkuyu Ezer
reason = '🚀 BALİNA İHLALİ (Cüretkar)';
}

const conf = confNum.toFixed(1);

const isBought = activeSymbols.some(activeSym => {
let aStr = activeSym.replace(/[^A-Za-z0-9]/g, '').toUpperCase();
let sStr = sym.replace(/[^A-Za-z0-9]/g, '').toUpperCase();
return aStr === sStr || aStr === sStr + 'T' || sStr === aStr + 'T';
});

const isHot = confNum > 85;

const nameClass = isBought ? "bought-blink" : (isWhaleOverride ? "hot-blink" : (isHot ? "hot-blink" : ""));
const nameStyle = (isBought || isHot || isWhaleOverride) ? "" : "color:#facc15;";

let bg = "rgba(255,255,255,0.02)";
let bColor = 'rgba(255,255,255,0.1)';
let confBadgeColor = 'color:#facc15; background:rgba(250,204,21,0.15);';

if (isWhaleOverride) { bg = "rgba(168, 85, 247, 0.2)"; bColor = "#c084fc"; confBadgeColor = 'color:#fff; background:linear-gradient(90deg, #9333ea, #ec4899);'; }
else if (conf > 90) { bg = "rgba(74, 222, 128, 0.15)"; bColor = "#4ade80"; } 
else if (conf > 80) { bg = "rgba(250, 204, 21, 0.1)"; bColor = "#facc15"; } 
else if (conf > 70) { bg = "rgba(248, 113, 113, 0.08)"; bColor = "#f87171"; } 

let boughtIcon = '';
if (isBought) {
bColor = "#22c55e";
bg = "rgba(22, 163, 74, 0.6)"; 
boughtIcon = '<span style="margin-left:4px;" title="Alım Yapıldı">✅</span>';
}

const price = t.price ? parseFloat(t.price).toFixed(2) : '0.00';
const change = t.change_pct ? parseFloat(t.change_pct).toFixed(1) : '0.0';
const isUp = parseFloat(change) >= 0;
const priceClass = isUp ? 'price-up' : 'price-down';
const arrow = isUp ? '↑' : '↓';
const target = t.tp_target ? parseFloat(t.tp_target).toFixed(2) : '-';

const rsiStr = rsiVal.toFixed(1);
const volStr = volVal.toFixed(1);
if (reason.length > 28) reason = reason.substring(0, 28) + '..';

const row = document.createElement('div');
row.className = 'flash-update';
row.style.cssText = `display:flex; flex-direction:column; background:${bg}; padding:6px; border-radius:4px; font-size:10px; font-family:'JetBrains Mono'; border-left: 3px solid ${bColor}; transition: 0.3s;`;

row.innerHTML = `
<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px;">
<div style="display:flex; align-items:center; flex-wrap:wrap;">
<span class="${nameClass}" style="font-weight:700; font-size:11px; ${nameStyle}">${sym}${boughtIcon}</span>
<span style="font-size:8px; padding:2px 5px; border-radius:4px; margin-left:6px; font-weight:bold; ${confBadgeColor}">Güven: %${conf}</span>
</div>
<span class="${priceClass}">$${price} ${arrow}</span>
</div>
<div style="display:flex; justify-content:space-between; font-size:8px; color:#f1f5f9; margin-bottom:2px;">
<span>RSI: ${rsiStr} | Hac: ${volStr}x</span>
<span style="color:#4ade80; font-weight:bold;">Hedef: $${target}</span>
</div>
<div style="font-size:8px; color:#e2e8f0; line-height:1.2;">
🎯 ${reason}
</div>
`;
bodyEl.appendChild(row);
};

cryptoItems.forEach(t => renderRow(t, cBody));
nasdaqItems.forEach(t => renderRow(t, nBody));
bistItems.forEach(t => renderRow(t, bBody));

if(cryptoItems.length === 0) cBody.innerHTML = '<div style="font-size:10px;text-align:center;color:#cbd5e1;grid-column: span 2;">Kripto bulunamadı</div>';
if(nasdaqItems.length === 0) nBody.innerHTML = '<div style="font-size:10px;text-align:center;color:#cbd5e1;grid-column: span 2;">NASDAQ bulunamadı</div>';
if(bistItems.length === 0) bBody.innerHTML = '<div style="font-size:10px;text-align:center;color:#cbd5e1;grid-column: span 2;">BIST bulunamadı</div>';
} catch (err) {
console.error("Top10 Momentum fetch error:", err);
}
}

// ================================================================
// 🩺 BOT SAĞLIK MONİTÖRÜ
// ================================================================
async function fetchBotHealth() {
try {
const t0 = Date.now();
const res = await fetch('/api/system/health');
const ping = Date.now() - t0;
const data = await res.json();

const pingEl = document.getElementById('botApiPing');
const wsEl = document.getElementById('botWsStatus');
const scanEl = document.getElementById('botLastScan2');
const errEl = document.getElementById('botErrorCount');
const dotEl = document.getElementById('botHealthDot');
const tsLastScan = document.getElementById('tsLastScan');

if (pingEl) { pingEl.innerText = ping + 'ms'; pingEl.style.color = ping < 100 ? '#4ade80' : (ping < 300 ? '#fde047' : '#f87171'); }
if (wsEl) wsEl.innerText = 'CANLI';
if (scanEl) scanEl.innerText = data.last_scan || '-';
if (tsLastScan) tsLastScan.innerText = data.last_scan || '-';
if (errEl) { errEl.innerText = data.error_count || 0; errEl.style.color = (data.error_count||0) > 0 ? '#f87171' : '#4ade80'; }
if (dotEl) { dotEl.style.background = '#4ade80'; dotEl.style.boxShadow = '0 0 6px #4ade80'; }
} catch(e) {
const dotEl = document.getElementById('botHealthDot');
const wsEl = document.getElementById('botWsStatus');
if (dotEl) { dotEl.style.background = '#f87171'; dotEl.style.boxShadow = '0 0 6px #f87171'; }
if (wsEl) wsEl.innerText = 'HATA';
}
}

// ================================================================
// 🌍 GLOBAL MAKRO ÖZET + 📢 EKONOMİK TAKVİM
// ================================================================
async function fetchMacroData() {
try {
const res = await fetch('/api/market/market-index/three-way');
const data = await res.json();
const body = document.getElementById('macroSummaryBody');
const upd = document.getElementById('macroLastUpdate');
if (body && data) {
const lines = [];
if (data.nasdaq_summary) lines.push(`🇺🇸 <b>NASDAQ:</b> ${data.nasdaq_summary}`);
if (data.bist_summary) lines.push(`🇹🇷 <b>BIST:</b> ${data.bist_summary}`);
if (data.crypto_summary) lines.push(`🪙 <b>Kripto:</b> ${data.crypto_summary}`);
if (data.global_assessment) lines.push(`🌍 <b>Genel:</b> ${data.global_assessment}`);
body.innerHTML = lines.length ? lines.join('<br>') : '<span style="color:#cbd5e1;">Veri bekleniyor...</span>';
}
if (upd) upd.innerText = new Date().toLocaleTimeString('tr-TR', {hour:'2-digit',minute:'2-digit'});
if (data.dxy) document.getElementById('macroDxy') && (document.getElementById('macroDxy').innerText = parseFloat(data.dxy).toFixed(2));
if (data.us_cpi) document.getElementById('macroCpi') && (document.getElementById('macroCpi').innerText = parseFloat(data.us_cpi).toFixed(1) + '%');
} catch(e) {
const body = document.getElementById('macroSummaryBody');
if (body) body.innerHTML = '<span style="color:#cbd5e1;font-size:10px;">Market index verisi yüklenemedi</span>';
}
}

async function fetchEconCalendar() {
// Statik takvim + dinamik haberlerden çek
try {
const res = await fetch('/api/market/news');
const data = await res.json();
const body = document.getElementById('econCalendarBody');
if (!body) return;
let news = [];
if (Array.isArray(data)) {
news = data;
} else {
news = data.news || data.items || data.data || [];
}
const econ = news.filter(n =>
n.type === 'economic' || n.category === 'calendar' ||
(n.headline||n.title||'').match(/CPI|NFP|Fed|FOMC|GDP|PCE|PMI|Merkez|faiz|enflasyon/i)
).slice(0, 5);

if (econ.length === 0) {
// Fallback: show static upcoming events
const staticEvents = [
{ time:'Çrş', event:'Fed FOMC Tutanakları', impact:'🔴', region:'🇺🇸' },
{ time:'Per', event:'ABD İstihdam (NFP)', impact:'🔴', region:'🇺🇸' },
{ time:'Cum', event:'TCMB Para Pol. Açıklaması', impact:'🔴', region:'🇹🇷' },
];
body.innerHTML = '';
staticEvents.forEach(ev => {
const row = document.createElement('div');
row.style.cssText = 'display:flex;align-items:center;gap:6px;background:rgba(251,146,60,0.06);border-radius:4px;padding:4px 6px;';
row.innerHTML = `<span style="font-size:9px;color:#cbd5e1;min-width:24px;">${ev.time}</span><span>${ev.region}</span><span style="font-size:10px;color:#e2e8f0;flex:1;">${ev.event}</span><span>${ev.impact}</span>`;
body.appendChild(row);
});
return;
}
body.innerHTML = '';
econ.forEach(n => {
const row = document.createElement('div');
row.style.cssText = 'border-radius:4px;padding:4px 6px;background:rgba(251,146,60,0.05);font-size:10px;color:#e2e8f0;';
row.innerText = `${n.headline || n.title || ''} (${n.time || n.timestamp || ''})`;
body.appendChild(row);
});
} catch(e) {}
}

// ================================================================
// 🤖 LLM CANLI PİYASA YORUMU
// ================================================================
let llmLastFetch = 0;
async function fetchLlmComment(force = false) {
const now = Date.now();
if (!force && now - llmLastFetch < 300000) return; // 5dk cache
llmLastFetch = now;
const body = document.getElementById('llmCommentBody');
const badge = document.getElementById('llmSentimentBadge');
const timeEl = document.getElementById('llmUpdateTime');
if (!body) return;
body.innerHTML = '<span style="color:#cbd5e1;font-style:italic;font-size:10px;">AI analiz üretiyor...</span>';
try {
const res = await fetch('/api/ide/analyst/custom', {
method:'POST', headers:{'Content-Type':'application/json'},
body: JSON.stringify({ prompt: `Şu an saat ${new Date().toLocaleTimeString('tr-TR',{hour:'2-digit',minute:'2-digit'})} TSİ. Kripto, BIST ve NASDAQ piyasaları için anlık 3 satır kısa piyasa yorumu yap. Türkçe, net, aksiyon odaklı. Her piyasa için bir cümle.` })
})
<truncated 2216 bytes>

NOTE: The output was truncated because it was too long. Use a more targeted query or a smaller range to get the information you need.