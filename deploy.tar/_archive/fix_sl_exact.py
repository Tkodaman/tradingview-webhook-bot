import asyncio
from core.logger import logger
from services.broker.factory import get_broker
from services.market_feed.live_stream import live_trade_manager

async def main():
    broker = get_broker("ALPACA", paper=True)
    alpaca_pos_raw = broker.get_open_positions()
    alpaca_pos = {}
    for p in alpaca_pos_raw:
        # alpaca_bridge get_open_positions returns raw dicts if successful
        sym = p.get('symbol', '')
        qty = float(p.get('qty', 0.0))
        alpaca_pos[sym] = qty
    
    for p in live_trade_manager.positions.values():
        if p.status == "OPEN":
            sym = p.symbol
            search_sym = sym.replace("/", "")
            exact_qty = alpaca_pos.get(search_sym, 0.0)
            
            if exact_qty > 0:
                print(f"Setting SL for {sym}. Local Qty: {p.quantity}, Alpaca Qty: {exact_qty}")
                order_id = broker.place_stop_loss_order(sym, 0, p.stop_loss_price, qty=exact_qty)
                if order_id:
                    p.broker_sl_order_id = order_id
                    print(f"Success -> {order_id}")
            else:
                print(f"Skipping {sym} - not found in Alpaca portfolio")

    live_trade_manager.save_state()
    print("Done")

if __name__ == "__main__":
    asyncio.run(main())
