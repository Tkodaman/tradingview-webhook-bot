with open('templates/dashboard.html', 'r', encoding='utf-8') as f:
    lines = f.readlines()

print('Gap starts at 3173:')
print(''.join(lines[3173:3190]))
