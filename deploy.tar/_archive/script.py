﻿# -*- coding: utf-8 -*-
with open('templates/dashboard.html', 'r', encoding='utf-8') as f:
    lines = f.readlines()
for i, l in enumerate(lines):
    if "fetchTop5Momentum" in l:
        print(f"Line {i}: {l.strip()}")
        break
