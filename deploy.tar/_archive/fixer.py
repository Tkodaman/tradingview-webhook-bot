import sys

with open('dashboard_recovered.html', 'r', encoding='utf-8') as f:
    lines = f.readlines()

print('Total lines in recovered:', len(lines))

html_end_idx = -1
for i, line in enumerate(lines):
    if '</body>' in line:
        html_end_idx = i
    if '</html>' in line:
        print('Found html end at', i)
        
print('body end at:', html_end_idx)

script_start_idx = -1
for i, line in enumerate(lines):
    if 'function ' in line and script_start_idx == -1:
        script_start_idx = i
        print('First function at', i)
        
