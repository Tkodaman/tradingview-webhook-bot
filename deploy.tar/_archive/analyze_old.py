import codecs

with codecs.open('dashboard_old.html', 'r', 'utf-16') as f:
    lines = f.readlines()

print('Length of dashboard_old.html in lines:', len(lines))

html_end_idx = -1
for i, line in enumerate(lines):
    if '</body>' in line:
        html_end_idx = i

print('body ends at:', html_end_idx)

# Search for the javascript end
for i, line in enumerate(lines):
    if '});' in line and 'MAKRO HABER FEED' in ''.join(lines[i:i+20]):
        print('Found boundary in old at', i+1)
        print(''.join(lines[i-5:i+5]))
