import asyncio
from core.logger import logger
from services.broker.factory import get_broker
from services.market_feed.live_stream import live_trade_manager
from routers.position_router import open_live_position, OpenPositionRequest
from core.config import settings

async def main():
    broker = get_broker("ALPACA", paper=True)
    
    # 1. Buy MNST
    print("Buying MNST...")
    req = OpenPositionRequest(symbol="MNST", capital=50.0, side="BUY", tp_pct=15.0, sl_pct=2.5)
    try:
        res = await open_live_position(req)
        print("MNST Result:", res)
    except Exception as e:
        print("Error buying MNST:", e)

    # 2. Register Stop Losses for ALL open positions
    print("Registering SL for all positions...")
    for p in live_trade_manager.positions.values():
        if p.status == "OPEN" and not p.broker_sl_order_id:
            # We use qty to avoid "insufficient balance" due to price changes in crypto.
            notional = p.quantity * p.entry_price
            print(f"Registering SL for {p.symbol} (Qty: {p.quantity}, SL: {p.stop_loss_price})")
            order_id = broker.place_stop_loss_order(p.symbol, notional, p.stop_loss_price, qty=p.quantity)
            if order_id:
                p.broker_sl_order_id = order_id
                print(f"Success -> SL ID: {order_id}")
            else:
                print(f"Failed for {p.symbol}")

    live_trade_manager.save_state()
    print("Done")

if __name__ == "__main__":
    asyncio.run(main())
