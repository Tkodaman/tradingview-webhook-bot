with open(r'templates\dashboard.html', 'r', encoding='utf-8') as f:
    c = f.read()

c = c.replace('if (!uiData || uiData.status !== "success") return;', 'if (!uiData) return;')

injection = '''                    if (msg.type === 'LIVE_MARKET') {
                        if (typeof renderTop5Momentum === 'function') {
                            renderTop5Momentum(msg.data);
                        }
'''
c = c.replace("if (msg.type === 'LIVE_MARKET') {", injection)

with open(r'templates\dashboard.html', 'w', encoding='utf-8') as f2:
    f2.write(c)
print('Injected!')
