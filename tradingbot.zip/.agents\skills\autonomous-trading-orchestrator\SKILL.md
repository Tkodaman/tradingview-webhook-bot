---
name: autonomous-trading-orchestrator
description: "Use when producing an autonomous trading decision, ranking opportunities, reviewing a TradingView signal, or coordinating data quality, regime, risk, execution, memory, and backtest skills."
---

# Autonomous Trading Orchestrator

Bu skill diğer trading skill'lerinin karar sırasını ve geçiş kapılarını yönetir. Amaç işlem sayısını artırmak değil, sermaye korunurken doğrulanmış avantajı kaçırmamaktır.

## Zorunlu Akış
1. **Data Quality Gate:** Veri taze, kaynaklar uyumlu, spread/likidite doğrulanmış mı?
2. **Market Regime Gate:** Trend, range, volatile veya shock rejimi nedir?
3. **Opportunity Ranking:** Momentum, volume, relative strength, VWAP/EMA ve multi-timeframe uyumu.
4. **Risk Gate:** Stop, target, R:R, position size, portfolio exposure, correlation ve daily loss.
5. **Execution Gate:** Idempotency, broker availability, fill state, slippage ve bracket protection.
6. **Memory Gate:** Asset/regime geçmişi yeterli mi? Toxic veya consecutive-loss kuralı var mı?
7. **Decision:** `BUY`, `SELL`, `HOLD`, `WAIT` veya `NO-TRADE`.
8. **Journal:** Karar gerekçesi, veri snapshot'ı, model sürümü ve sonuç takibi.

## Fırsat Kaçırmama Kuralı
Teyitsiz erken giriş yerine koşullu alarm üret:
- breakout seviyesi
- retest seviyesi
- hacim eşiği
- geçersizlik seviyesi
- veri tazeliği süresi

Böylece sinyal kaçırılmaz, fakat teyit gelmeden sermaye riske atılmaz.

## Yasaklar
- Eksik veriyi varsayılan değerle doldurup BUY üretme.
- LLM güvenini piyasa olasılığı gibi sunma.
- Backtest win-rate'ini canlı başarı garantisi sayma.
- Broker fill olmadan OPEN gösterme.
- PAPER doğrulaması olmadan LIVE önermeme.
- Kullanıcı onayı olmadan canlı moda veya risk gevşetmeye geçmeme.

## Çıktı Sözleşmesi
Her kararda şu alanlar bulunur:
- `decision`
- `asset`, `market`, `timeframe`
- `data_timestamp`, `data_age_seconds`, `data_quality`
- `regime`, `entry_context`, `confirmation_required`
- `invalidation`, `hard_stop`, `target`, `risk_reward`
- `risk_amount`, `size_limit`, `portfolio_exposure`
- `execution_state`, `broker_status`
- `facts`, `assumptions`, `uncertainties`
- `reason`, `next_check_at`

Kanıt yetersizse sonuç `NO-TRADE` olmalıdır.
